id = 34193440.0
[match, local str = "0.001 0.002 0.003"
torch.Tensor({{str:match("(%d+%.%d*)%s+(%d+%.%d*)%s+(%d+%.%d*)")}})
, 0.001 *
  1.0000  2.0000  3.0000
[torch.DoubleTensor of size 1x3]
, tonumber, tonumber("0x12") == 18]