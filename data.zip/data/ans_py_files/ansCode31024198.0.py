id = 31024198.0
[nn.Identity(), (), nn.Module, __call__, __call__, nn.Identity()(), nngraph.Node({module=self}), nn.Identity(), local i2h = nn.Linear(input_size, 4 * rnn_size)(input)  -- input to hidden
, nngraph, nn.Module, nngraph.gModule]