id = 43134813.0
[t, __index, train_set, __index, train_set, k, train_set.k, __index (train_set, "k"), local x = train_set [1], { train_set.data[i], train_set.label[i] }]