id = 35886539.0
[ a = torch.ByteTensor{1,0,1,0,1}
 print(torch.nonzero(a))                                                                                         
 1                                                                                                                  
 3                                                                                                                  
 5                                                                                                                  
[torch.LongTensor of size 3x1]
,  a = torch.ByteTensor{1,2,1,6,1}
 a:eq(1):nonzero()
]