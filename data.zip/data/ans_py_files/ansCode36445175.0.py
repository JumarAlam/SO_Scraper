id = 36445175.0
[gradInput, gradOutput, d_C/d_input_L, d_C/d_output_L, gradInput, gradOutput, gradInput, gradOutput, L, Loss, f, accGradParameters, d_C/d_Weight_L, d_C/d_bias_L, gradWeight, gradBias, gradOutput, self.gradWeight:addr(scale, gradOutput, input)
, gradOutput, self.gradBias:add(scale, gradOutput)
, scale]