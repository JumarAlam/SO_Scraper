id = 42482819.0
[view(), reshape(), a, import torch
a = torch.range(1, 16)
, 4 x 4, a = a.view(4, 4)
, a, 4 x 4, a, 3 x 5, x = self.pool(F.relu(self.conv2(x)))]