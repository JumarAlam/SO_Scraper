id = 44527447.0
[AB = A.mm(B)

AB = torch.mm(A, B)

AB = torch.matmul(A, B)

AB = A @ B  # Python 3.5+ only
, torch.mm, torch.matmul(), torch.mm, torch.matmul, torch.matmul, A * B  # element-wise matrix multiplication (Hadamard product)
]