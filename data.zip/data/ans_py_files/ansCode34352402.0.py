id = 34352402.0
[$ qlua
 require 'image'
 w = image.display(image.lena()) -- with positional arguments mode
 image.display{image=image.fabio(), win=w} -- with named arguments mode
]