id = 36616902.0
[print, __tostring, tostring, tostring,  t = setmetatable({}, {__tostring = function(x) return "foo" end})
 print(t)
foo
, __tostring, __tostring__,   do local Foo = torch.class("Foo"); function Foo:__tostring__() return "this is foo" end end
  f = Foo(); print(f)
 this is foo
, __tostring__]