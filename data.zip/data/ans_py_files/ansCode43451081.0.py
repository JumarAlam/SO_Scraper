id = 43451081.0
[torch.unsqueeze(input, dim, out=None),  import torch
 a = torch.Tensor([1, 2, 3, 4, 5])
 a

 1
 2
 3
 4
 5
[torch.FloatTensor of size 5]

 a = a.unsqueeze(0)
 a

 1  2  3  4  5
[torch.FloatTensor of size 1x5]
]