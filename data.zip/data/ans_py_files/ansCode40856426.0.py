id = 40856426.0
[nn.utils.addSingletonDimension]