id = 40260514.0
[qlua, luajit, torch, luarocks, qlua, $ luarocks install qtlua
$ luarocks install qttorch
$ which qlua
/home/me/torch/install/bin/qlua
$ qlua
Lua 5.1 Copyright (...)
 require('image')
 l = image.lena()
 image.display(l)
 
, qlua]