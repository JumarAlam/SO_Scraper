id = 42035109.0
[k, for k = 1,nScales do, for scale = -3,2,.25 do table.insert(self.scales,scale), pos, nScales, k-th, k, temp, x, y, M(:), local temp=sortedIds[pos[scale]][scale], local sc=sc:view(h*w)
local sS,sIds=torch.sort(sc,true)
local sz = sS:size(1)
sortedScores:narrow(2,s,1):narrow(1,1,sz):copy(sS)
sortedIds:narrow(2,s,1):narrow(1,1,sz):copy(sIds), sortedIds, x, y]