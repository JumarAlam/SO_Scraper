id = 36853619.0
[eval(), correct_prediction, print correct_prediction.eval(feed_dict={x: batch_xs, y: batch_ys})
]