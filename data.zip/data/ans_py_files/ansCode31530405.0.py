id = 31530405.0
[nn_, "#define nn_", init.c, #define nn_(NAME) TH_CONCAT_3(nn_, Real, NAME)
, nn_(Tanh_updateOutput), generic/Tanh.c, generic/Tanh.c, .c]