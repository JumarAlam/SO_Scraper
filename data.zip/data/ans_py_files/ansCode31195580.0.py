id = 31195580.0
[ firstHalf = torch.Tensor(firstHalf)
 secondHalf = torch.Tensor(secondHalf)
 presentWord = torch.Tensor(presentWord)
,  completeProfile = firstHalf:cat(secondHalf):cat(presentWord)
, function appender(t)
   local last = 0
   return function(i, v)
       last = last + 1
       t[last] = v
   end
end

completeProfile = torch.Tensor(#firstHalf + #secondHalf + #presentWord)

profile_append = appender(completeProfile)

table.foreach(firstHalf, profile_append)
table.foreach(secondHalf, profile_append)
table.foreach(presentWord, profile_append)
]