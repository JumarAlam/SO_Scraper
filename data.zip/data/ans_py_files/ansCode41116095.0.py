id = 41116095.0
[model:add(nn.Reshape(28*28)), ……./torch/install/share/lua/5.1/nn/THNN.lua:110: Need input of dimension 3 and input.size[0] == 1 but got input to be of shape: [199 x 28 x 28] at /tmp/luarocks_nn-scm-1-2325/nn/lib/THNN/generic/SpatialConvo‌​lutionMM.c:47
]