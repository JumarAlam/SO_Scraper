id = 36489444.0
[sudo python, import theano, make, ./[name_of_the_sample], sudo]