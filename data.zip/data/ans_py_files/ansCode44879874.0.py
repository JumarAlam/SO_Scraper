id = 44879874.0
[p = torch.exp(vector.dot(ht))
, vector, ht, ht, cuda.FloatTensor, vector, vector = vector.cuda()
, cuda.FloatTensor, .cpu(), .data.cpu(), ht = ht.cpu()
]