id = 43440637.0
[ x=torch.Tensor{{1,2,3,4,},{5,6,7,8,}}
 y=x:index(2,torch.LongTensor{1,3,4})
 --return:
  1  3  4
  5  7  8
, x[{{},{2,3}}]=x[{{},{3,4}}]
x=x:view(2,3)
]