id = 43458096.0
[netR:evaluate()
, training(), evaluate(), BatchNormalization]