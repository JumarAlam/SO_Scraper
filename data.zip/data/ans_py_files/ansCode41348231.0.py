id = 41348231.0
[package.loadlib, require, require, package.loadlib, package.loadlib, /home/dazhen/torch/install/share/lua/5.1/trepl/init.lua]