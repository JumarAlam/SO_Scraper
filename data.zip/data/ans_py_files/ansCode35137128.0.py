id = 35137128.0
[dataset[i] = {input[i], output}, output[1], output]