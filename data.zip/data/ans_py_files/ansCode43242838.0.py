id = 43242838.0
[nn.View, nn.View(−1, out_channels * out_height * out_width), nn.View(-1, 2048)]