id = 28515146.0
[torch.DoubleTensor.nn.L1Cost_updateOutput
torch.FloatTensor.nn.L1Cost_updateOutput
, input = torch.FloatTensor()
input.nn.L1Cost_updateOutput(...) 
]