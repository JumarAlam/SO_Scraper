id = 42471535.0
[denominator[1][1], -- W and P are of size NxN, r is of size N
delta_W = P * r:view(N, 1) * r:view(1, N) * P  -- this is an NxN
denominator = 1 + r:view(1, N) * P * r:view(N, 1)  -- this is a 1x1
delta_W = delta_w / denominator[1][1]
W = W + delta_W
, P:t()]