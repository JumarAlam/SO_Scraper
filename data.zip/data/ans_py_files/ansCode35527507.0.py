id = 35527507.0
[local softMaxLayer = cudnn.LogSoftMax():cuda()
model:add(softMaxLayer)
]