id = 45564530.0
[nn.Module, self.opt, self.my_var, .cuda(), -use_gpu, maybe_cuda(variable), variable.cuda(), opt.cuda, class MyModule(nn.Module):
    def __init__(self, opt):
        super(MyModule, self).__init__()
        self.opt = opt

    def maybe_cuda(self, variable):
        if self.opt.cuda:
            return variable.cuda()
        return variable

class Model(MyModule):
    def __init__(self, opt, other_arg):
        super(Model, self).__init__(opt)

        self.linear = nn.Linear(opt.size1, opt.size2)
        self.W_out = nn.Parameter(_____)

    def forward(self, ____):
        # create a variable, put it on GPU if possible
        my_var = self.maybe_cuda(Variable(torch.zeros(___)))
]