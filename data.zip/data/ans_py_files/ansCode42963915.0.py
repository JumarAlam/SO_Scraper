id = 42963915.0
[local myFile = hdf5.open('/path/to/write.h5', 'w')
, myFile:write('/path/to/data', torch.rand(5, 5))
]