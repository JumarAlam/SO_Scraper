id = 44876150.0
[Tensor * Tensor, Variable * Variable, Tensor * Variable, Tensor, Variable, y_variable = torch.autograd.Variable(y_tensor, requires_grad=False)
x_variable * y_variable # returns Variable
, Variables, Tensors]