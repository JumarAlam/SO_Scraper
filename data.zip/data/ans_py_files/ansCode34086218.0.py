id = 34086218.0
[mydata = torch.class('something')
mydata = nil
soemthing = nil

-- remove the global registration:
debug.getregistry()['something'] = nil    

-- now it is possible to register the class again
mydata2 = torch.class('something')
]