id = 39926312.0
[nIputPlane, nOutputPlane, nInputPlane  = 3, nOutputPlane, nOutputPlane]