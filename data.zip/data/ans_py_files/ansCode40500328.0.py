id = 40500328.0
[&lt;ctrl - \ , /setTestArgs, map &lt;C-\ :exec("tag /".expand("&lt;cword"))&lt;CR, .vimrc]