id = 38545506.0
[for i = 1, n do
threads:addjob(
           function()
              __resetflag = true
            end
)
while true do
        threads:addjob(
           function()
              if __resetflag == true then f:reset(); __resetflag = false; end
              x,y = f:getBatch()
              return x,y
           end,
           function(x,y)
              -- do some stuff and trigger conditionMet = true if met
           end
        )
        if conditionMet == true break end

end
end
]