id = 33059235.0
[torch.mm, prod = torch.mm(a,b), /* this is the tensor that will hold the results */
arg1 = THDoubleTensor_new(); 
THDoubleTensor_resize2d(arg1, arg5-size[0], arg6-size[1]);
arg3 = arg1;
/* .... */
luaT_pushudata(L, arg1, "torch.DoubleTensor");
/* effective matrix multiplication operation that will fill arg1 */
THDoubleTensor_addmm(arg1,arg2,arg3,arg4,arg5,arg6);
, calloc, prod, prod, torch.mm(prod,a,b), prod, gemm,   real *a_ = a;
  for(i = 0; i &lt; m; i++)
  {
    real *b_ = b;
    for(j = 0; j &lt; n; j++)
    {
      real sum = 0;
      for(l = 0; l &lt; k; l++)
        sum += a_[l*lda]*b_[l];
      b_ += ldb;
      /*
       * WARNING: beta*c[j*ldc+i] could give NaN even if beta=0
       *          if the other operand c[j*ldc+i] is NaN!
       */
      c[j*ldc+i] = beta*c[j*ldc+i]+alpha*sum;
    }
    a_++;
  }
, torch.mm(a,b), torch.mm(prod,a,b), prod, prod, THDoubleTensor_fill(arg1, 0);, prod, torch.mm(prod,a,b)]