id = 41345372.0
[model.modules[1].weight, model:get(1).weight, params, gradParams = model:parameters()]