id = 30036454.0
[printT = function(t)
   t = t:view(-1)
   for i=1,t:nElement() do
      io.write(t[i] .. ',')
   end
end

printT(mlp:get(1).weight)
printT(mlp:get(1).bias)

printT(mlp:get(3).weight)
printT(mlp:get(3).bias)

printT(mlp:get(5).weight)
printT(mlp:get(5).bias)
]