id = 25249911.0
[-- This assumes `t1` is a 2-dimensional tensor!
local t2 = {}
for i=1,t1:size(1) do
  t2[i] = {}
  for j=1,t1:size(2) do
    t2[i][j] = t1[i][j]
  end
end
, torch.totable(object)]