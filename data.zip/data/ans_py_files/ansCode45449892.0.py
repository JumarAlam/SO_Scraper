id = 45449892.0
[dtype=torch.cuda.FloatTensor
x=torch.autograd.Variable(x.type(dtype))
, network.cuda(), def forward(self,x):
    x=self.input_layer(x)
    x=self.middle_layer(x)
    x=self.output_layer(x)
    return x
, def__init__(self,feature_size,hidden_size,output_size):
     self.input_layer=nn.Linear(feature_size,hidden_size)
     self.middle_layer=nn.Linear(hidden_size,hidden_size)
     self.output_layer=nn.Linear(hidden_size,output_size)
, your_tensor.view(batch_size,feature_size)]