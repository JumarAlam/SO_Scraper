id = 45461669.0
[self.input_layer, forward(), self.network.cuda(), FeedForward, self.input_layer, forward(), self.output_layer]