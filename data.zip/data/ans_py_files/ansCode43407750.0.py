id = 43407750.0
[local lfs = require('lfs')

local deletedir
deletedir = function(dir)
    for file in lfs.dir(dir) do
        local file_path = dir..'/'..file
        if file ~= "." and file ~= ".." then
            if lfs.attributes(file_path, 'mode') == 'file' then
                os.remove(file_path)
                print('remove file',file_path)
            elseif lfs.attributes(file_path, 'mode') == 'directory' then
                print('dir', file_path)
                deletedir(file_path)
            end
        end
    end
    lfs.rmdir(dir)
    print('remove dir',dir)
end


deletedir('tmp')
]