id = 36039480.0
[torch.updateerrorhandlers(), hi from Lua func
Lua error code 2: inconsistent tensor size at /tmp/luarocks_torch-scm-1-1092/torch7/lib/TH/generic/THTensorMath.c:384
stack traceback:
        [C]: at 0x7f63cd831360
        [C]: in function 'dot'
        [string "return ..."]:9: in function &lt;[string "return ..."]:2
, torch.updateerrorhandlers(),     lua_getglobal(L, "torch");
    lua_getfield(L, -1, "updateerrorhandlers");
    lua_replace(L, -2);
    assert(lua_pcall(L, 0, 0, 0) == 0);
, torch.updateerrorhandlers(), my_func_index, lua_pcall, torch.updatethreadlocals(), lua_pcall,     lua_getglobal(L, "torch");
    lua_getfield(L, -1, "updatethreadlocals");
    lua_replace(L, -2);
    assert(lua_pcall(L, 0, 0, 0) == 0);
]