id = 32636004.0
[local parallel = nn.ParallelTable()
parallel:add(part1)
parallel:add(part2)

local net = nn.Sequential()
net:add(parallel)                   -- (A)
net:add(nn.JoinTable(1))            -- (B)
net:add(part3)                      -- (C)
, parallel, part1, part2, nn.JoinTable, 1]