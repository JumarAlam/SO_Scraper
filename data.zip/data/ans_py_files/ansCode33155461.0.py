id = 33155461.0
[local a = 5
local b = a
, b, do local inspect = require 'inspect'; print(inspect) end
, $ inspect = require 'inspect'
$ print(inspect)
]