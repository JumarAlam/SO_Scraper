id = 35963871.0
[function fill_0normal(t,sigma) do
  t:normal(0, sigma)
end
]