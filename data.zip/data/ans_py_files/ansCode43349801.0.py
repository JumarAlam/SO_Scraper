id = 43349801.0
[. ~/torch/install/bin/torch-activate, ~/.bashrc, test.sh]