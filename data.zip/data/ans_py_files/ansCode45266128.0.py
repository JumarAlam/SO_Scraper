id = 45266128.0
[foo:bar, foo.bar, self, function Foo:bar( ... ), function Foo.bar( self, ... ), foo:bar( ... ), foo.bar( foo, ... ), foo, function BatchLoader:new()
    setmetatable({}, BatchLoader) -- creates a table &amp; throws it away
    self.epoch_done = false       -- self is the hidden first argument
    return self
end

local trainLoader = BatchLoader:new()  -- i.e. BatchLoader.new( BatchLoader )
, function BatchLoader:new()
    setmetatable({}, BatchLoader)
    BatchLoader.epoch_done = false
    return BatchLoader
end
, -- fixed creation scheme
function BatchLoader.new( )
   local self = { epoch_done = false }
   return setmetatable( self, BatchLoader )
end

-- acceptable uses:
local trainLoader = BatchLoader.new( )
local trainLoader = BatchLoader:new( ) -- ignores passed self
, -- permit passing base object
function BatchLoader:new( )  -- equivalently: BatchLoader.new( self )
   self = self or { }  -- use passed table or create new
   self.epoch_done = false
   return setmetatable( self, BatchLoader )
end

-- acceptable uses:
local trainLoader = BatchLoader.new( )  -- creates from scratch
local trainLoader = BatchLoader.new { n = 23 } -- re-uses this table
-- WRONG uses:
local trainLoader = BatchLoader:new( )  -- reuses BatchLoader class as object
, function BatchLoader:init(X, y, sids, batch_size, argshuffle)
, function BatchLoader.init(self, X, y, sids, batch_size, argshuffle)
, local X_train, y_train, sid_train = 
  trainLoader.init( X, y, ... )
, trainLoader:init( X, y, ... ), trainLoader, self]