id = 46575124.0
[conv1d, Conv1d, conv1.double(), model.double(), Conv1d, self.conv1 = nn.Conv1d(300, 128, kernel_size=5, padding=2)
, class Net(nn.Module):
    def __init__(self):
        super(Net, self).__init__()
        self.conv1 = nn.Conv1d(300, 128, kernel_size=5, padding=2)
        self.conv2 = nn.Conv1d(128, 64, kernel_size=2, padding=1)
        self.conv2_drop = nn.Dropout()
        self.fc1 = nn.Linear(64, 20)
        self.fc2 = nn.Linear(20, 2)

    def forward(self, x):
        x = F.relu(F.avg_pool1d(self.conv1(x), 2, padding=1))
        x = F.relu(F.avg_pool1d(self.conv2_drop(self.conv2(x)), 2))
        x = x.view(1, -1) # bonus fix, Linear needs (batch_size, in_features) and not (in_features, batch_size) as input.
        x = F.relu(self.fc1(x))
        x = F.dropout(x, training=self.training)
        return self.fc2(x)

if __name__ == '__main__':

    t = Variable(torch.randn((1, 300, 1))).double() # t is a double tensor
    model = Net()
    model.double() # this will make sure that conv1d will process double tensor
    out = model(t)
]