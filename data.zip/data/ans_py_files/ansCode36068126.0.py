id = 36068126.0
[seq.zip, seq.zip, zip, local zip
do
  local unpack = table.unpack or unpack
  local function zip_select( i, var1, ... )
    if var1 then
      return var1, select( i, var1, ... )
    end
  end

  function zip( ... )
    local iterators = { n=select( '#', ... ), ... }
    for i = 1, iterators.n do
      assert( type( iterators[i] ) == "table",
              "you have to wrap the iterators in a table" )
      if type( iterators[i][1] ) ~= "number" then
        table.insert( iterators[i], 1, -1 )
      end
    end
    return function()
      local results = {}
      for i = 1, iterators.n do
        local it = iterators[i]
        it[4], results[i] = zip_select( it[1], it[2]( it[3], it[4] ) )
        if it[4] == nil then return nil end
      end
      return unpack( results, 1, iterators.n )
    end
  end
end

-- example code (assumes that this file is called "zip.lua"):
local t1 = { 2, 4, 6, 8, 10, 12, 14 }
local t2 = { "a", "b", "c", "d", "e", "f" }
for a, b, c in zip( {ipairs( t1 )}, {ipairs( t2 )}, {io.lines"zip.lua"} ) do
  print( a, b, c )
end
]