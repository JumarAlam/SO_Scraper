id = 43080779.0
[pytorch, Module, Module,  class Model(nn.Module):
        def __init__(self):
            super(Model, self).__init__()
            self.conv1 = nn.Conv2d(1, 20, 5)
            self.conv2 = nn.Conv2d(20, 20, 5)
, Module, super(QuestionClassifier, self).__init__()
]