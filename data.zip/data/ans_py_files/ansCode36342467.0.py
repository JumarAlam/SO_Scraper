id = 36342467.0
[nn.BatchNormalization, image:reshape(1,3,32,32), nn.View, output_size = channels*height*width    -- (512 in your case)
view = nn.View(output_size)
, batch_size x channels x height x width, batch_size, batch_size*channels*height*width, output_size, batch_size, 1*channels*height*width, output_size, nn.View, NB, view:setNumInputDims(NB)
]