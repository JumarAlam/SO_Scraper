id = 44815975.0
[args = parser.parse_args(), sys.argv[1:], $:python prog.py --config afilename 
, args = parser.parse_args(['--config', 'afilename'])
, import sys
print(sys.argv)
]