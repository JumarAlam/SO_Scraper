id = 37742897.0
[nclasses = 2, y[1] = values[#values] + 1, y, n, n]