id = 46356206.0
[text_batch = torch.stack(batch['text'], 0)[:, indices]
, tensor.size()]