id = 33808446.0
[CUDA_VISIBLE_DEVICES, export CUDA_VISIBLE_DEVICES=0
luajit your-script.lua
]