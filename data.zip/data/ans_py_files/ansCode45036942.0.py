id = 45036942.0
[self.transfer, transfer, mlp, output, gradInput, require 'nn'

module = nn.ReLU()

net = nn.Sequential():add(nn.Linear(2,2)):add(module):add(nn.Linear(2,1)):add(module)

input = torch.Tensor(2,2):random()
net:forward(input)

print(net:get(2).output)
print(net:get(4).output)
, module, nn.ReLU()]