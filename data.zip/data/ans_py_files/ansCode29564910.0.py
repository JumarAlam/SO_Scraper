id = 29564910.0
[net:add(nn.Transpose({1,2},{2,3},{3,4}))
convLayer = nn.SpatialConvolutionCUDA
, convLayer = nn.SpatialConvolution
]