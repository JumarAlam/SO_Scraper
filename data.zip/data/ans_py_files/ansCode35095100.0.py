id = 35095100.0
[number, nn.ClassNLLCriterion, nn.LogSoftMax(), nn.SoftMax(), nn.CrossEntropyCriterion]