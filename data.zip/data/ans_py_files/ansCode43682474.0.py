id = 43682474.0
[CDivTable, null, 2x3, SplitTable(dim), dim, ratioPerceptron:add(nn.SplitTable(1)), local ratioPerceptron = nn.Sequential();
ratioPerceptron:add(nn.Narrow(1, 1, 2));
ratioPerceptron:add(nn.SplitTable(1))
ratioPerceptron:add(nn.CDivTable());
ratioPerceptron:add(nn.Reshape(N, 1));
ratioPerceptron:add(nn.Linear(1, 1));
ratioPerceptron:add(nn.Sigmoid());
, print, print(ratioPerceptron:forward(input))]