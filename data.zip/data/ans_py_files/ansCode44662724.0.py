id = 44662724.0
[i = torch.LongTensor([[0, 1, 2], [5, 5, 5], [8, 8, 8]]),   0   0   0   2   0
  0   0   0   0   0
  0   0   0   0  20
[torch.cuda.FloatTensor of size 3x5 (GPU 0)]
, [[0 , 2],
 [3 , 4]]
, i=torch.LongTensor([[0, 2], [3, 4]])
v=torch.FloatTensor([2, 20])
s=torch.Size([3, 5])
a_ = torch.sparse.FloatTensor(indices, values, size).cuda()
, Assertion 'dstIndex &lt; dstAddDimSize' failed.]