id = 41734950.0
[correct_prediction.eval(), tf.session.run(correct_prediction), sess.run(), correct_prediction.eval(feed_dict={x: batch_xs, y: batch_ys}), optimizer = optimizer = tf.train.AdamOptimizer().minimize(cross_entropy)
, cross_entropy, sess.run([cross_entropy, y_conv],feed_dict={x: batch_xs, y: batch_ys})
, optimizer]