id = 40149660.0
[(7,1,1,1,1,1,1) &lt;--First class representation
.......
(1,1,1,1,1,1,7) &lt;--Last class representation
,  (1,1,1,1,1,1,1) &lt;--First class representation
 .......
 (7,7,7,7,7,7,7) &lt;--Last class representation
, 1 .. 7]