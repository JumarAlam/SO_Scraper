id = 44608320.0
[expand(), repeat(), expand(), repeat(), import torch

L = 10
N = 20
A = torch.randn(L,L)
A.expand(N, L, L) # specifies new size
A.repeat(N,1,1) # specifies number of copies
, np.tile(), np.repeat(), np.repeat(), np.tile(), import numpy as np

L = 10
N = 20
A = np.random.rand(L,L)
np.tile(A,(N, 1, 1))
]