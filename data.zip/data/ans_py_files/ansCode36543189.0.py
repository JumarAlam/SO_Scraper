id = 36543189.0
[sudo apt-get --purge remove ipython
sudo pip uninstall ipython
git clone https://github.com/ipython/ipython.git
cd ipython
sudo pip install -e . 
]