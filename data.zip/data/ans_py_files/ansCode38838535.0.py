id = 38838535.0
[local function makeMatrix(initialVal, ...)
    local isfunc = type(initialVal) == "function"
    local dimtable = {...}
    local function helper(depth)
        if depth == 0 then
            return isfunc and initialVal() or initialVal
        else
            local plane = {}
            for i = 1, dimtable[depth] do
                plane[i] = helper(depth-1)
            end
            return plane
        end
    end
    return helper(#dimtable)
end

p = makeMatrix(0, 2, 3, 5) -- makes 3D matrix of size 2x3x5 with all elements initialized to 0

makeMatrix(torch.Tensor, m ,n)
]