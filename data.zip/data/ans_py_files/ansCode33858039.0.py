id = 33858039.0
[nn, nn.Concat, nn.Select, local net = nn.Concat(1)
for i=1, d do
  local subNet = nn.Sequential()
  subNet:add(nn.Select(1, i))
  subNet:add(nn.View(-1):setNumInputDims(2))
  subNet:add(nn.Replicate(1, 1))
  net:add(subNet)
end
, nn.Replicate, d*a x b*c]