id = 34166405.0
[torch.IndexCopy, array:indexCopy(1, indices, torch.Tensor({1, 2, 3}))
]