id = 37467742.0
[{...},  {...}              -- creates a list with all vararg parameters
, {1}, 1, xTrain, Tensor, torch.linespace()]