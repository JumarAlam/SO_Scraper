id = 45102798.0
[class ImageLoader(torch.utils.data.Dataset):
def __init__(self, root, tform=None, imgloader=PIL.Image.open):
    super(ImageLoader, self).__init__()

    self.root=root
    self.filenames=sorted(glob(root))
    self.tform=tform
    self.imgloader=imgloader

def __len__(self):
    return len(self.filenames)

def __getitem__(self, i):
    out = self.imgloader(self.filenames[i])  # io.imread(self.filenames[i])
    if self.tform:
        out = self.tform(out)
    return out
, source_dataset=ImageLoader(root='/dldata/denoise_ae/clean/*.png', tform=source_depth_transform)
target_dataset=ImageLoader(root='/dldata/denoise_ae/clean_cam_n9dmaps/*.png', tform=target_depth_transform)
source_dataloader=torch.utils.data.DataLoader(source_dataset, batch_size=32, shuffle=False, drop_last=True, num_workers=15)
target_dataloader=torch.utils.data.DataLoader(target_dataset, batch_size=32, shuffle=False, drop_last=True, num_workers=15)
, dataiter = iter(source_dataloader)
images = dataiter.next()
print(images.size())
, for i, (source, target) in enumerate(zip(source_dataloader, target_dataloader), 0):
    source, target = Variable(source.float().cuda()), Variable(target.float().cuda())
]