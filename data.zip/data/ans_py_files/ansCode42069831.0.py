id = 42069831.0
[if nArgs == 1 and input == nil then
   error(utils.expectingNodeErrorMessage(input, 'inputs', 1))
end
, local w_join_feat_dim = nn.View(-1,input_size*4,1)(w_join_feat_dim)
local p_join_feat_dim = nn.View(-1,input_size*4,1)(p_join_feat_dim)
local q_join_feat_dim = nn.View(-1,input_size*4,1)(q_join_feat_dim)
, local w_join_feat_dim = nn.View(-1,input_size*4,1)(w_join_feat)
local p_join_feat_dim = nn.View(-1,input_size*4,1)(p_join_feat)
local q_join_feat_dim = nn.View(-1,input_size*4,1)(q_join_feat)
, *_join_feat_dim]