id = 31403876.0
[perceptron_general, gradOutput, gradOutput, gradientWrtOutput = {
    torch.Tensor{realTarget[1]},
    torch.Tensor{realTarget[2]}
}
]