id = 40576151.0
[-- Function that builds a gModule
function buildModule(input_size,hidden_size)
    local x = nn.Identity()()
    local out = x - nn.Linear(input_size,hidden_size) - nn.Tanh()
    return nn.gModule({x},{out})
end

network = buildModule(5,3)

new_network = nn.Sequential()
new_network:add(network)
new_network:add(nn.Linear(3,10))
]