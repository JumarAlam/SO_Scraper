id = 46291089.0
[w.grad
, w.data -= learning_rate * w.grad.data
, optimizer = torch.optim.SGD(model.parameters(), lr=0.01)
]