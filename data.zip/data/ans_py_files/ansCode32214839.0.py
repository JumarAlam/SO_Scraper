id = 32214839.0
[class Cat:
    def __init__(self, name):
        self.name = name
    def info(self):
        print 'I am a cat and I am called', self.name
, __init__, self, c = Cat('Kitty')
c.info()
, I am a cat and I am called Kitty
]