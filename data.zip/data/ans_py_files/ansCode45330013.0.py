id = 45330013.0
[t = nn.Sequential()
t:add(nn.Linear(3,2))
t:add(nn.Reshape(2,1))
, clone, mlp = nn.Sequential()
c = nn.Parallel(1,2)
for i = 1, 10 do
    c:add(t:clone('weight', 'bias'))
end
mlp:add(c)
]