id = 44635614.0
[float(), torch.FloatTensor of size 1, mean, mean, x, float, mean, x = x - mean[0]
, mean, x, x = x - mean.expand_as(x)
]