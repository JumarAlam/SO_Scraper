id = 36021397.0
[new, self._getFromThreads, self._pushResult, nil, new, __index, local self = setmetatable({}, DataThreads)
, return self
]