id = 44719369.0
[numpy, 64-bit floating point, torch.DoubleTensor, Double, numpy, Float, float, data_utils.TensorDataset(torch.from_numpy(X).float(), torch.from_numpy(Y).float())
, model.double()
, Float, Double]