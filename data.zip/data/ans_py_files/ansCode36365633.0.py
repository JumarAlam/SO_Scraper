id = 36365633.0
[net:get(6).output]