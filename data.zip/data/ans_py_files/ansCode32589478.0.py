id = 32589478.0
[df_do, nn.Criterion, nn.MSECriterion, df_do, nn.ClassNLLCriterion, df_do]