id = 43779546.0
[Network, Network, optimizer = optim.SGD(Network().parameters(), lr=0.001, momentum=0.9)
, Network]