id = 33495984.0
[/opt/zbstudio/bin/linux/x64/lua version is LuaJIT 2.0.2
"lua" command alone points to /usr/bin/lua, and it is Lua 5.1.5
~/torch/install/share/lua/5.1 seemed to contain Lua 5.1
~/torch/install/bin/luajit is 2.1.0-alpha
]