id = 46273998.0
[layer {
  name: "input-data"
  type: "DummyData"
  top: "data"
  top: "im_info"
  dummy_data_param {
    shape { dim: 1 dim: 3 dim: 224 dim: 224 }
  }
}
, input: "data"
input_shape: {
dim: 1
dim: 3
dim: 224
dim: 224
}
, layer {
  name: "conv1"
  type: "Convolution"
  bottom: "data" -- **here put data instead of input-data**
  top: "conv1"
  convolution_param {
    num_output: 96
    kernel_size: 3
    pad: 1
    stride: 1
  }
}
]