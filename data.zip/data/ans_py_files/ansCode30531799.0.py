id = 30531799.0
[nn.Tanh(), act_function = nn.Tanh
perceptron:add( act_function() )
, nn, // torch/nn/generic/Tanh.c/Tanh_updateGradInput:

for(i = 0; i &lt; THTensor_(nElement)(gradInput); i++)
    {
        real z = ptr_output[i];
        ptr_gradInput[i] = ptr_gradOutput[i] * (1. - z*z);
    }
]