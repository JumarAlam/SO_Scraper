id = 34643788.0
["c:\Program Files (x86)\Microsoft Visual Studio 9.0\VC\bin\vcvars32.bat", luarocks]