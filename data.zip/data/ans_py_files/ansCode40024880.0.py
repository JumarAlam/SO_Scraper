id = 40024880.0
[orig = np.r_[z[0], np.diff(z)]
]