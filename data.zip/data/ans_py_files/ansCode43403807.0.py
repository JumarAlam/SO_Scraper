id = 43403807.0
[torcy.save('mynet.t7',net, params, grad_params = net:getParameters()]