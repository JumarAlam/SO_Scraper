id = 44375813.0
[U, (r1 - r2) * U + r2, (r1 - r2) * torch.rand(a, b) + r2
, torch.FloatTensor(a, b).uniform_(r1, r2)
, r1 = 2 # Create uniform random numbers in half-open interval [2.0, 5.0)
r2 = 5

a = 1  # Create tensor shape 1 x 7
b = 7
, (r1 - r2) * torch.rand(a, b) + r2, torch.rand(a, b), a x b, x = torch.rand(a, b)
print(x)
# tensor([[0.5671, 0.9814, 0.8324, 0.0241, 0.2072, 0.6192, 0.4704]])
, (r1 - r2) * torch.rand(a, b), print((r1 - r2) * x)
tensor([[-1.7014, -2.9441, -2.4972, -0.0722, -0.6216, -1.8577, -1.4112]])
, (r1 - r2) * torch.rand(a, b) + r2, print((r1 - r2) * x + r2)
tensor([[3.2986, 2.0559, 2.5028, 4.9278, 4.3784, 3.1423, 3.5888]])
, (r2 - r1) * torch.rand(a, b) + r1, torch.rand(a, b), x = torch.rand(a, b)
print(x)
# tensor([[0.5671, 0.9814, 0.8324, 0.0241, 0.2072, 0.6192, 0.4704]])
, (r2 - r1) * torch.rand(a, b), print((r2 - r1) * x)
# tensor([[1.7014, 2.9441, 2.4972, 0.0722, 0.6216, 1.8577, 1.4112]])
, (r2 - r1) * torch.rand(a, b) + r1, print((r2 - r1) * x + r1)
tensor([[3.7014, 4.9441, 4.4972, 2.0722, 2.6216, 3.8577, 3.4112]])
, (r1 - r2) * torch.rand(a, b) + r2, (r2 - r1) * torch.rand(a, b) + r1]