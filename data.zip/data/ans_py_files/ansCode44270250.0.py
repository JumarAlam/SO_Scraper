id = 44270250.0
[tmp, tmp, mount, /etc/fstab, /tmp]