id = 38286666.0
[x = torch.Tensor(2, 2):fill(2)

z = torch.div(x, 2) --will return a new Tensor with the result of x / 2.
torch.div(z, x, 2) --will put the result of x / 2 in z.
x:div(2) --will divide all elements of x with 2 in-place.
z:div(x, 2) --puts the result of x / 2 in z.
]