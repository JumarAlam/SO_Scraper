id = 42555217.0
[require 'dpnn'

aaa = torch.DoubleTensor(3,32,200)
bbb = torch.DoubleTensor(3,32,54)

model = nn.Sequential()
par = nn.ParallelTable()
par:add(nn.SplitTable(1))
par:add(nn.SplitTable(1))
model:add(par)
model:add(nn.ZipTable())
model:forward({aaa,bbb})
]