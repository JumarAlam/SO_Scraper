id = 42470928.0
[external_command.lua, -- args has been set by the caller
if not args or #args == 0 then
    print('no input_parameter')
else
    print('#args = ' .. #args, 'input_parameter: ' .. args[1])
end
, function runfile(f, ...)
    local tmp = args  -- save the original global args
    args = table.pack(...)
    dofile(f)
    args = tmp  -- restore args
end
, th runfile('ext_command.lua', 10)
#args = 1       input_parameter: 10
                                                                      [0.0002s]
th runfile('ext_command.lua', 'a', 'b', 'c')
#args = 3       input_parameter: a
                                                                      [0.0002s]
]