id = 45121168.0
[:threads(function()
            require 'models/Reorg'
            local cudnn = require 'cudnn'
            cudnn.fastest, cudnn.benchmark = fastest, benchmark
         end)
]