id = 45141148.0
[requires_grad, # Load your model
model = torchvision.models.resnet18(pretrained=True)

# Disable gradient computation for all parameters
for param in model.parameters():
    param.requires_grad = False

# Enable gradient computation for a specific layer (here the last fc layer)
for param in model.fc.parameters():
    param.requires_grad = True

# Optimize only the the desired parameters (for you latent vectors)
optimizer = optim.SGD(model.fc.parameters(), lr=1e-2, momentum=0.9)
]