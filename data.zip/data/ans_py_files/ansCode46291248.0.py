id = 46291248.0
[from torchvision import models    
model_vgg = models.vgg16(pretrained=True)
for param in model_vgg.parameters():
    param.requires_grad = False
, decoder = nn.Linear(10, 100) 
decoder.weight = #Do anything which is valid.
]