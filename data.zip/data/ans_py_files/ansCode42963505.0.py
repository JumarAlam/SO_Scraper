id = 42963505.0
[-- First get the maximum element and indices per row
maxP_per_row, bestColumn_per_row = torch.max(out,2)
-- then get the best element and the best row
best_p, best_row = torch.max(maxP_per_row, 1)
-- then find the best column for the best row
best_col = bestColumn_per_row[best_row]
]