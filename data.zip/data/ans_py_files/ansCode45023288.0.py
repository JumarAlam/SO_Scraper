id = 45023288.0
[hidden_size, input_size, num_layers, hidden_size * num_layers, (seq_len, batch, input_size), seq_len, batch, (num_layers, batch, hidden_size), hidden_size * num_directions, num_directions, output_size = hidden_size, out_rnn, hn = rnn(input, (h0, c0))
lin = nn.Linear(hidden_size, output_size)
v1 = nn.View(seq_len*batch, hidden_size)
v2 = nn.View(seq_len, batch, output_size)
output = v2(lin(v1(out_rnn)))
]