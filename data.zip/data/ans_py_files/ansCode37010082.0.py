id = 37010082.0
[import numpy
import Image

## boot strap lutorpy
import lutorpy as lua
require('torch')

getImage = numpy.asarray(Image.open("image.jpg"))
a = torch.fromNumpyArray(getImage)

# now you can use your image as torch Tensor
# for example: use SpatialConvolution from nn to process the image
require("nn")
n = nn.SpatialConvolution(1,16,12,12)
res = n.forward(n, a)
print(res._size())

# convert back to numpy array
output = res.asNumpyArray()
]