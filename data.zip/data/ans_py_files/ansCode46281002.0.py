id = 46281002.0
[@Override
protected void onStart() {
    super.onStart();

    camera = Camera.open(); //Also Call this
    params = camera.getParameters(); //and this, in the Constructor
}
, private Camera camera;
Parameters params;
]