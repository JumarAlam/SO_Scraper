id = 38962017.0
[torch, app.lua, require 'torch'
require 'nn'

image = require 'image'
ParamBank = require 'ParamBank'
label     = require 'classifier_label'
torch.setdefaulttensortype('torch.FloatTensor')
torch.setnumthreads(4)

SpatialConvolution = nn.SpatialConvolutionMM
SpatialMaxPooling = nn.SpatialMaxPooling
ReLU = nn.ReLU
SpatialSoftMax = nn.SpatialSoftMax
, classifyImage]