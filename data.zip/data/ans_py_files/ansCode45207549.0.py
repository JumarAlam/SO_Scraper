id = 45207549.0
[nn.Module, .cuda(), encoder, decoder, train(), encoder = encoder.cuda()
decoder = decoder.cuda()
, Variable, Variable, .cuda()]