id = 30983647.0
[()(), (), call, function foo()
  return function() print(42) end
end

foo()()   -- 42
]