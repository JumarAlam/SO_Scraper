id = 38079230.0
[cd /usr/bin/
mv gcc gcc-6.1-back
mv g++ g++-6.1-back
ln -s gcc-4.9 gcc
ln -s g++-4.9 g++
]