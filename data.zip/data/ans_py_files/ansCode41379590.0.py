id = 41379590.0
[cudnn.benchmark = true
]