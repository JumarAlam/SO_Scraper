id = 33437671.0
[-v, arg, local exe, i = arg[ 0 ], -1
while arg[ i ] do
  exe, i = arg[ i ], i-1
end
print( exe )
, /proc, ls -l /proc/4425/exe
, 4425, /opt/zbstudio/bin/linux/x64/lua]