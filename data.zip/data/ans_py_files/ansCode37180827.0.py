id = 37180827.0
[narrow, narrow, select, sub, Storage, th x = torch.Tensor{{1, 2}, {3, 4}}

th y = x:narrow(1, 2, 1)

th print(x:storage():data())
cdata&lt;double *: 0x0079f240

th print(y:storage():data())
cdata&lt;double *: 0x0079f240
, set, th x:set(y)
 3  4
[torch.DoubleTensor of size 1x2]
, x = y]