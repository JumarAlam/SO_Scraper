id = 35762524.0
[nn, cunn, luarocks install nn
luarocks install cunn
]