id = 33249861.0
[nvcc -o im2col -I/deep/u/ibello/torch/include im2col.cu 
, THGeneral.h, /deep/u/ibello/torch/include/TH, nvcc -o im2col -I/deep/u/ibello/torch/include -I/deep/u/ibello/torch/include/TH im2col.cu 
]