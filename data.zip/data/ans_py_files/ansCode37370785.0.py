id = 37370785.0
[t2h_d.data.module:share(shared_weights[1], 'weight', 'bias')
, nn.Linear(size1, 4 * size1)(h_t):annotate{name='ih_'..L}  
]