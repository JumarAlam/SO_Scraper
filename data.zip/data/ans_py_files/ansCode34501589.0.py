id = 34501589.0
[require 'torch'
cmd = torch.CmdLine()
cmd:argument('-model','model checkpoint to use for sampling')
, cmd:argument('-model','/cv/model lm_chelm_checkpoint_epoch50.00_2.5344.t7'
'model checkpoint to use for sampling')
, th sample.lua cv/lm_chelm_checkpoint_epoch50.00_2.5344.t7
]