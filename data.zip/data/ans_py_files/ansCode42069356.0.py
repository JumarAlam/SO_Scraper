id = 42069356.0
[rm -rf ~/torch, cutorch, cunn, luarocks, luarocks install class, torch.CudaTensor, Tensor]