id = 42373279.0
[-help, th MyScript.lua -help
]