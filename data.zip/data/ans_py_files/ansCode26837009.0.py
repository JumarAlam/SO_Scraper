id = 26837009.0
[libcunn.so, git clone https://github.com/torch/cunn.git
ls cunn
cmake -E make_directory build
cd build/
cmake .. -DCMAKE_BUILD_TYPE=Release -DCMAKE_PREFIX_PATH="/usr/local/bin/.." -DCMAKE_INSTALL_PREFIX="/usr/local/lib/luarocks/rocks/cunn/scm-1" &amp;&amp; make
, Linking CXX shared module libcunn.so
, cp libcunn.so /usr/local/lib/lua/5.1/libcunn.so
]