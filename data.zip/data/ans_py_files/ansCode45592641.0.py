id = 45592641.0
[nn.Module, nn.Sequential(), class Flatten(nn.Module):
    def forward(self, x):
        return x.view(x.size()[0], -1)
, x.size()[0], -1, nn.Sequential, main = nn.Sequential()
self._conv_block(main, 'conv_0', 3, 6, 5)
main.add_module('max_pool_0_2_2', nn.MaxPool2d(2,2))
self._conv_block(main, 'conv_1', 6, 16, 3)
main.add_module('max_pool_1_2_2', nn.MaxPool2d(2,2)) 
main.add_module('flatten', Flatten())
]