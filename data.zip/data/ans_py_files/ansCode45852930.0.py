id = 45852930.0
[backward(), repeat
  local output = model:forward(input) --see what model predicts
  local loss = criterion:forward(output, answer) --see how wrong it is
  local loss_grad = criterion:backward(output, answer) --see where it is the most wrong
  model:backward(input,loss_grad) --see how much each particular parameter of network is responsible for error
  model:updateParameters(learningRate) --fix the parameters based on their wrongness
  model:zeroGradParameters() --network parameters are different now, so old gradients are of no use now
until is_user_satisfied()
, updateParameters, getParameters(), local model_parameters,model_parameters_gradient=model:getParameters()
, optim.sgd, optim.sgd(
   function_to_return_error_and_its_gradients, 
   model_parameters,
   optimizer_special_settings)
, model_parameters]