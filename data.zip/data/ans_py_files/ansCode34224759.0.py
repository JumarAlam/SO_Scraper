id = 34224759.0
[x = torch.Tensor(2, 4, 4)
x[1]:fill(0)
x[2]:fill(1)

-- this creates tensors of size 1x4x4
-- the first dimension is narrowed, one index at a time
a = x:narrow(1, 1, 1)
b = x:narrow(1, 2, 1)
,  print(a)
(1,.,.) = 
  0  0  0  0
  0  0  0  0
  0  0  0  0
  0  0  0  0
[torch.DoubleTensor of size 1x4x4]

 print(b)
(1,.,.) = 
  1  1  1  1
  1  1  1  1
  1  1  1  1
  1  1  1  1
[torch.DoubleTensor of size 1x4x4]
]