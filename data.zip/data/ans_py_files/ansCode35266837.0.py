id = 35266837.0
[    dataSize = Data.data:size()[1]
    shuffleIdx = torch.randperm(dataSize)
    Data.data = Data.data:index(1,shuffleIdx:long())
    Data.labels = Data.labels:index(1,shuffleIdx:long())
]