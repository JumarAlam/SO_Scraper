id = 42680568.0
[s[i:j:k], x = i + n*k, 0 &lt;= n &lt; (j-i)/k, i, i+k, i+2*k, i+3*k, len(s), s[999:9999], s[len(s):len(s)], len(s) &lt; 999, 1]