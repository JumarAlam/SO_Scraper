id = 32570711.0
[nn.ClassNLLCriterion, batch_size, class, batch_size x 1, class[i], class = class:view(-1)
, network:add( nn.LogSoftMax() )
criterion = nn.ClassNLLCriterion()
, criterion = nn.CrossEntropyCriterion()
, nn.CrossEntropyCriterion, nn.ClassNLLCriterion]