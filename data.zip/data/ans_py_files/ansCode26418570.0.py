id = 26418570.0
[C:\Program Files\Torch, path.lua=[[C:\Program Files\Torch\bin\torch-lua]], &lt;ZBS\cfg\user.lua, Project | Run, F6, local torch = require 'torch'
local data = torch.Tensor{
   {68, 24, 20},
   {74, 26, 21},
   {80, 32, 24}
}
print(data)
, lua51.dll, libtorch-lua.dll, Torch/bin, mkforwardlib.lua, mkforwardlib-gcc.lua, lua mkforwardlib.lua libtorch-lua lua51 X86, lua51.dll, lua51.dll, Torch\bin, Project | Start Debugging]