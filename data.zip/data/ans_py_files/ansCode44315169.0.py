id = 44315169.0
[state_dict(), for k, v in model_2.state_dict().iteritems():
    print("Layer {}".format(k))
    print(v)
, modules(), for layer in model_2.modules():
   if isinstance(layer, nn.Linear):
        print(layer.weight)
]