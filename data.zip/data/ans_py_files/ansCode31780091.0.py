id = 31780091.0
[nn.gModule, idx, sentence_idx, node_idx, nil]