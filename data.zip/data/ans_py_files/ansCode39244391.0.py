id = 39244391.0
[LUA_PATH, LUA_CPATH, LUA_CPATH=/path/to/?.so, LUA_CPATH_5_3=/path/to/?.so, package.loadlib, local function loadlib(path, name)
  local sep = string.sub(package.config, 1, 1)
  local file = path .. sep .. name .. ((sep == '/') and '.so' or '.dll')
  local func = 'luaopen_' .. name
  local loader, msg = package.loadlib(file, func)
  assert(loader, msg)
  return assert(loader())
end

local mylib = loadlib([[/path/to]], 'mylib')
]