id = 43943292.0
[inf, (torch.nn.utils.clip_grad_norm(model.parameters(), 0.1))]