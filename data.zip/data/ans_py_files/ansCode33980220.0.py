id = 33980220.0
[nan, base_lr, loss_weight, base_lr, 'inf', 'nan', 'nan', ... sgd_solver.cpp:106] Iteration 0, lr = -nan
, 'solver.prototxt', lr_policy: "poly", max_iter, lr = nan, nan, InfogainLoss, nan, nan, nan, nan, nan, nan, "Pooling", stride, kernel_size, nan, layer {
  name: "faulty_pooling"
  type: "Pooling"
  bottom: "x"
  top: "y"
  pooling_param {
    pool: AVE
    stride: 5
    kernel: 3
  }
}
, nan, y, "BatchNorm", "BatchNorm", nan, debug_info, debug_info: true, 'solver.prototxt']