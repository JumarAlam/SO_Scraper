id = 36278337.0
[narrow, narrow, ten[{{1,2},1}], 2, ten[{{1,2},{2}}], 2x1, th trsize = 10
th trdata = torch.Tensor(trsize, 3, 32, 32)
th subdata = trdata[{ {1, 5} }]
th subdata:size()
  5
  3
 32
 32
[torch.LongStorage of size 4]
]