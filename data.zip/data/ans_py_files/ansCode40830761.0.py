id = 40830761.0
[boundingRect, import numpy as np
import cv2

mask = np.zeros([600,600], dtype=np.uint8)
mask[200:500,200:500] = 255                 # set some values to 255 to represent an actual mask
rect = cv2.boundingRect(mask)               # function that computes the rectangle of interest
print(rect)

img = np.ones([600,600, 3], dtype=np.uint8) # arbitrary image
cropped_img = img[rect[1]:(rect[1]+rect[3]), rect[0]:(rect[0]+rect[2])] # crop the image to the desired rectangle 
, mask, img]