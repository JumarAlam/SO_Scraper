id = 46337117.0
[pytorch, tensorflow, pytorch, forward, class MyNet(nn.Module):
    def __init__(input_nc, output_nc):
        super().__init__()
        # define layers 
        # ...
        self.choice_A = nn.Conv2d(input_nc, output_nc, kernel_size = 3)
        self.choice_B = nn.Conv2d(input_nc, output_nc, kernel_size = 4)
        # continue init

    def forward(self, x, epoch):
        # start forward pass
        # ...
        if epoch % 2 == 0:
            x = self.choice_A(x)
        else:
            x = self.choice_B(x)
        # ...
        return x
]