id = 45024451.0
[output1 = self.Batch1(self.ReLu1(self.Lin1(input)))
, h1 = self.ReLu1(self.Lin1(input))
h2 = self.Batch1(h1)
, RuntimeError: matrices expected, got 3D, 2D tensors at /py/conda-bld/pytorch_1493681908901/work/torch/lib/TH/generic/THTensorMath.c:1232
, Variable(torch.rand(dim1, dim2)), input.size(), self.ReLu1(self.Lin1(Variable(torch.rand(10, 20)))).size(),  rnn = nn.RNN(10, 20, 2)
 input = Variable(torch.randn(5, 3, 10))
 h0 = Variable(torch.randn(2, 3, 20))
 output, hn = rnn(input, h0)
]