id = 38666999.0
[np.diff, 1...N, cumsum, diff, cumsum, orig = np.insert(np.diff(z), 0, z[0])
, insert, np.concatenate, orig = np.concatenate((np.array(z[0]).reshape(1,), np.diff(z)))
, 1...N, orig = z.copy()
orig[1:] = np.diff(z)
]