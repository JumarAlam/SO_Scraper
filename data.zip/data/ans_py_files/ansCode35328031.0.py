id = 35328031.0
[yi = f(xi)
   = log( exp(xi) / sum_j(exp(xj)) )
   = xi - log( sum_j(exp(xj)) )
, dyi/dxi = 1 - exp(xi) / sum_j(exp(xj))
, dyi/dxk = - exp(xk) / sum_j(exp(xj))
, 1-E(x1)     -E(x2)     -E(x3)    ...
 -E(x1)    1-E(x2)     -E(x3)    ...
 -E(x1)     -E(x2)    1-E(x3)    ...
...
, E(xi) = exp(xi) / sum_j(exp(xj)), gradInputi = sum_j( gradOutputj . dyj/dxi )
, gradInput = transpose(Jf) . gradOutput
, gradInputi = gradOutputi - E(xi) . sum_j( gradOutputj )
, sum_j( gradOutputj ), 1 / sum_j(exp(xj)), 1 / sum_j(exp(xj)), sum_j(exp(outputj)) = sum_j(exp( log(exp(inputj) / sum_k(exp(inputk) ))
                    = sum_j(         exp(inputj) / sum_k(exp(inputk)  )
                    = 1
, gradInputi = gradOutputi - exp(outputi) . sum_j( gradOutputj )
]