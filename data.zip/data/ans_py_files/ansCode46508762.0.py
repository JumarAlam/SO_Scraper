id = 46508762.0
[:cuda(), cudnn.xxx, cudnn]