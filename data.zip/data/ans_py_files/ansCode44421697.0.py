id = 44421697.0
[y_i = x_i, if x_i = min_value or x_i &lt;= max_value
    = min_value, if x_i &lt; min_value
    = max_value, if x_i  max_value
, z=torch.clamp(x,0,1), torch.clamp(z,x,0,1), x:clamp(0,1), z:clamp(x,0,1)]