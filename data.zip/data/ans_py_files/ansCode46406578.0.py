id = 46406578.0
[def mse_loss(input, target):
            return ((input - target) ** 2).sum() / input.data.nelement() 
, torch.autograd]