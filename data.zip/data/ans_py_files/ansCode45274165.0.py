id = 45274165.0
[DataParallel, encoderchar, DataParallel, dim=1, encoderchar = torch.nn.DataParallel(encoderchar, device_ids=[0, 1, 2, 3, 4, 5, 6, 7], dim=1)
, w = w.view(batch_size, -1)
]