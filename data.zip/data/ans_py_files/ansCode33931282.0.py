id = 33931282.0
[require 'nn'
require 'torch'
require 'rnn'

lstm = nn.Sequencer(
   nn.Sequential()
      :add(nn.LSTM(1,100))
      :add(nn.Linear(100,1))
      :add(nn.Sigmoid())
   )

-- Encapsulate thr criterion using a Sequencer
-- Just provide the entire sequence as input and the corresponding
-- target sequence as expected output
criterion = nn.SequencerCriterion(nn.BCECriterion())

data = torch.zeros(10,2)
for i=1,data:size(1) do
  data[i][1] = torch.uniform()
  data[i][2] = torch.uniform()
end

local inputs, targets = {},{}

for epoch=1,5 do
  lstm:training()

  for i=1,data:size(1) do
    --useful for minibatch
    inputs[1] = torch.zeros(1)
    inputs[1][1] = data[i][1]

    targets[1] = torch.zeros(1)
    targets[1][1] = data[i][2]

    local output = lstm:forward(inputs)
    local err = criterion:forward(output, targets)

    local gradOutputs = criterion:backward(output, targets)
    -- Sequencer handles the backwardThroughTime internally
    lstm:backward(inputs, gradOutputs)
    lstm:updateParameters(0.01)
    lstm:zeroGradParameters()

    inputs = {}
    targets = {}
  end
end
]