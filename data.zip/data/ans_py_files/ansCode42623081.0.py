id = 42623081.0
[MobileBarcodeScanner, FlashButtonText, &lt;Border Grid.Row="0" Visibility="Collapsed" VerticalAlignment="Top" HorizontalAlignment="Right" Width="120" Height="80"
    &lt;Button x:Name="buttonToggleFlash" Click="buttonToggleFlash_Click"Flash&lt;/Button
&lt;/Border 
]