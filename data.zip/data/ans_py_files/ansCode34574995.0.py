id = 34574995.0
[t = { 0,  -1,  -3,
      6,   5,   0,
      0.3, 0.6, 0.9 }

for _,n in ipairs(t) do
  if n  0 then               --only for positives
    if ans == nil then
      ans = n                 --first positive assumed lowest
    else
      if n &lt; ans then ans = n end  --if a lower value is found, replaces previous one
    end
  end
end

print('Answer',ans)
, t = { 0,  -1,  -3,
      6,   5,   0,
      0.3, 0.6, 0.9 }

for i,n in ipairs(t) do
  if n  0 then               --only for positives
    if ans == nil then
      ans = n                 --first positive assumed lowest
      pos = i
    else
      if n &lt; ans then         --if a lower value is found, replaces previous one
        ans = n
        pos = i               --keep position
      end
    end
  end
end

print('Answer '.. ans ..' at position '.. pos)
]