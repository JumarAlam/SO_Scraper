id = 38255264.0
[CrossEntropyCriterion(), LogSoftMax, ClassNLLCriterion, yourModel:forward(), ClassNLLCriterion]