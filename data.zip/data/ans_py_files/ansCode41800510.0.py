id = 41800510.0
[random, nil, rand]