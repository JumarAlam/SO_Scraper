id = 42362794.0
[print model, model = torch.load(path_to_model):cuda()
avg_pooling_layer = model:get(position_of_the_avg_pooling_layer)
, print avg_pooling_layer, weights = avg_pooling_layer.weight -- get the weights of the layer
output = avg_pooling_layer.output  -- get the output of the layer
, torch.load, cifar_10 = torch.load("path_to_cifar-10.t7")
]