id = 44944540.0
[index = torch.LongTensor([1,0,2])
, var[index] = var
]