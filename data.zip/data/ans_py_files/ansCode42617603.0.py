id = 42617603.0
[os.execute("th test.lua -visiualize 0")
]