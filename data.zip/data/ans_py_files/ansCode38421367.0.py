id = 38421367.0
[torch.serialize, serialized_batch = nil
collectgarbage()
collectgarbage()
, mnist = require 'mnist'
local dataset = mnist[mode .. 'dataset']()

-- PROBLEMATIC LINE BELOW --
local ext_resource = dataset.data:reshape(dataset.data:size(1),
  dataset.data:size(2) * dataset.data:size(3)):double()

-- Create a Dataframe with the label. The actual images will be loaded
--  as an external resource
local df = Dataframe(
  Df_Dict{
    label = dataset.label:totable(),
    row_id = torch.range(1, dataset.data:size(1)):totable()
  })

-- Since the mnist package already has taken care of the data
--  splitting we create a single subsetter
df:create_subsets{
  subsets = Df_Dict{core = 1},
  class_args = Df_Tbl({
    batch_args = Df_Tbl({
      label = Df_Array("label"),
      data = function(row)
        return ext_resource[row.row_id]
      end
    })
  })
}
, local mem = {}
table.insert(mem, collectgarbage("count"))

local ser_data = torch.serialize(batch.dataset)
table.insert(mem, collectgarbage("count"))

local ser_retriever = torch.serialize(batch.batchframe_defaults.data)
table.insert(mem, collectgarbage("count"))

local ser_raw_retriever = torch.serialize(function(row)
  return ext_resource[row.row_id]
end)
table.insert(mem, collectgarbage("count"))

local serialized_batch = torch.serialize(batch)
table.insert(mem, collectgarbage("count"))

for i=2,#mem do
  print(i-1, (mem[i] - mem[i-1])/1024)
end
, 1   0.0082607269287109  
2   358.23344707489 
3   0.0017471313476562  
4   358.90182781219 
, 1   0.0094480514526367  
2   0.00080204010009766 
3   0.00090408325195312 
4   0.010146141052246
, setfenv]