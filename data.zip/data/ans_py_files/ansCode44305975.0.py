id = 44305975.0
[import torch
from torch.autograd import Variable
x = Variable(torch.FloatTensor([[1,2],[3,4]]), requires_grad=True)
y = x + 2
z = y * y
gradient = torch.ones(2, 2)
z.backward(gradient)
print(x.grad)
, Variable containing:
  6   8
 10  12
[torch.FloatTensor of size 2x2]
]