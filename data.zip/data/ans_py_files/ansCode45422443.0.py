id = 45422443.0
[batch_size = 8
img_size = 224

transformer = transforms.Compose(
    [transforms.ToTensor(),
     transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])



class GoodsDataset(Dataset):
    def __init__(self, csv_file, root_dir):
        """
        Args:
            csv_file (string): Path to the csv file with annotations.
            root_dir (string): Directory with all the images.
            transform (callable, optional): Optional transform to be applied
                on a sample.
        """
        self.data = pd.read_csv(csv_file)
        self.root_dir = root_dir
        self.le = preprocessing.LabelEncoder()
        self.le.fit(self.data.loc[:, 'category'])

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        img_name = os.path.join(self.root_dir, str(self.data.loc[idx, 'id']) + '.jpg')
        image = (Image.open(img_name))
        good = self.data.iloc[idx, :].as_matrix()
        label = self.le.transform([good[2]])
        return [transformer(image), label]
, train_ds = GoodsDataset("topthree.csv", "resized")
train_set = dataloader = torch.utils.data.DataLoader(train_ds, batch_size = batch_size, shuffle = True)
]