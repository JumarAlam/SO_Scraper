id = 36897020.0
[array = np.zeros(5) # array = [0 0 0 0 0]
indices = np.array([0, 2, 4])
array[indices] = np.array([1, 2, 3]) # array = [1 0 2 0 3]

require("torch")
# convert numpy array to torch tensor
tensor = torch.fromNumpyArray(array) 

# put your torch code here

#convert back to numpy array
array = tensor.asNumpyArray()
# now array is sharing memory with tensor 
]