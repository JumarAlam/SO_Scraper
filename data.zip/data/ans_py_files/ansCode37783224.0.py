id = 37783224.0
[cd ~/torch-android;, git submodule update --init --recursive;, ./build;]