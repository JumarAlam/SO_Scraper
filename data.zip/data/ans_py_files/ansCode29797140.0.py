id = 29797140.0
[luarocks install inspect, local inspect = require 'inspect', assert(inspect(setmetatable({a=1}, {b=2}) == [[{
  a = 1
  &lt;metatable = {
    b = 2
  }
}]]))
, print(inspect(myobj))
]