id = 45368796.0
[dim=0, dim=0, dim=1, def custom_imshow(tensor):
    if tensor.dim() == 4:
        count = 1
        for i in range(tensor.size(0)):
            img = tensor[i].numpy()
            plt.subplot(1, tensor.size(0), count)
            img = img / 2 + 0.5     # unnormalize
            img = np.transpose(img, (1, 2, 0))
            count += 1
            plt.imshow(img)
            plt.axis('off')

    if tensor.dim() == 5:
        count = 1
        for i in range(tensor.size(0)):
            for j in range(tensor.size(1)):
                img = tensor[i][j].numpy()
                plt.subplot(tensor.size(0), tensor.size(1), count)
                img = img / 2 + 0.5  # unnormalize
                img = np.transpose(img, (1, 2, 0))

                plt.imshow(img)
                plt.axis('off')
                count +=1
, x,  x.size()
torch.Size([4, 5, 3, 32, 32])
 custom_imshow(x)
, x.view(-1, 3, 32, 32),  # x.size() - torch.Size([4, 5, 3, 32, 32])
  x = x.view(-1, 3, 32, 32)
  x.size()
 torch.Size([20, 3, 32, 32])
  custom_imshow(x)
, # x.size() - torch.Size([20, 3, 32, 32])
 x.view(4, 5, 3, 32, 32)
 x.size()
torch.Size([4, 5, 3, 32, 32])
 custom_imshow(x)
]