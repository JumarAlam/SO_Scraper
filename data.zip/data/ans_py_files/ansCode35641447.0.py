id = 35641447.0
[debug.getinfo(3), debug.getinfo(3).name, nil, require, debug.getinfo(3).name, pcall, debug.getinfo(3), __name__ = '__main__']