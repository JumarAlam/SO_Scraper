id = 34175121.0
[Torch, function apply_to_slices(tensor, dimension, func, ...)
    for i, slice in ipairs(tensor:split(1, dimension)) do
        func(slice, i, ...)
    end
    return tensor
end
, function power_fill(tensor, i, power)
    power = power or 1
    tensor:fill(i ^ power)
end

A = torch.Tensor(5, 6)

apply_to_slices(A, 1, power_fill)

 1  1  1  1  1  1
 2  2  2  2  2  2
 3  3  3  3  3  3
 4  4  4  4  4  4
 5  5  5  5  5  5
[torch.DoubleTensor of size 5x6]

apply_to_slices(A, 2, power_fill, 3)

   1    8   27   64  125  216
   1    8   27   64  125  216
   1    8   27   64  125  216
   1    8   27   64  125  216
   1    8   27   64  125  216
[torch.DoubleTensor of size 5x6]
]