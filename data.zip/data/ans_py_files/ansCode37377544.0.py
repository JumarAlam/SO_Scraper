id = 37377544.0
[cdata, ffi.copy, require 'torch'
ffi = require 'ffi'

-- create a random float array
n = 3
x = torch.rand(n):float()
cdata = x:data()
assert(type(cdata) == 'cdata')

-- copy this cdata into a destination tensor
y = torch.FloatTensor(n)
ffi.copy(y:data(), cdata, n*ffi.sizeof('float'))

assert(x:equal(y))
]