id = 24091502.0
[typename, typedef, template&lt;typename T
struct test {
    using type = T; // no typename required
    using underlying_type = typename T::type // typename required
};
, typename, template&lt;typename T
struct test {
    // typename required
    using type = typename std::conditional&lt;true, const T&amp;, T&amp;&amp;::type;
    // no typename required
    using integer = std::conditional&lt;true, int, float::type;
};
, template, template&lt;typename T
struct test {
    template&lt;typename U
    void get() const {
        std::cout &lt;&lt; "get\n";
    }
};

template&lt;typename T
void func(const test&lt;T&amp; t) {
    t.get&lt;int(); // error
}
, t.get&lt;int(), main.cpp:13:11: error: expected primary-expression before 'int'
     t.get&lt;int();
           ^
main.cpp:13:11: error: expected ';' before 'int'
, template, t.template get&lt;int(), t.get &lt; int]