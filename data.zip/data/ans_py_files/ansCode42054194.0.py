id = 42054194.0
[import torch.utils.data as data_utils

train = data_utils.TensorDataset(features, targets)
train_loader = data_utils.DataLoader(train, batch_size=50, shuffle=True)
, features, targets, features, targets, TensorData, data_tensor, target_tensor, assert data_tensor.size(0) == target_tensor.size(0)
, FloatTensor, view, 2d_dataset = 4d_dataset.view(5000, -1)
, -1]