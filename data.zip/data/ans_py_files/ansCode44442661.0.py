id = 44442661.0
[nngraph, __call__, (), __unm__, -, __sub__, -, nngraph]