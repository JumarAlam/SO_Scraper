id = 41473055.0
[params = cmd:parse()
local tmptab = {}
for word in params.cuda_device:gmatch("%w+") do
  tmptab[#tmptab +1] = word
end
params.cuda_device = tmptab
for i,v in pairs(params.cuda_device) do
   -- some code here
end
, getmetatable('').__index = function(str,i)
  if(type(i) == "number") then
    return string.sub(str,i,i)
  else
    return ""
  end 
end
]