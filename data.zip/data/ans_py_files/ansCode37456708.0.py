id = 37456708.0
[x, function foo(a, b)
    local a = a or 0
    local b = b or "foo"
end
, and, or, x and y, y, x, nil, false, x, x or y, y, x, x, or, -- x and y
if x then
    return y
else
    return x
end
-- x or y
if x then
    return x
else
    return y
end
, _nidx_ =  (_nidx or 0) + 1, _nidx_]