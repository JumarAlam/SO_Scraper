id = 37876642.0
[max_size, self:get_max_size()
, myClass:get_max_size()
]