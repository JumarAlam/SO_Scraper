id = 35387967.0
[a = torch.Tensor([1,2,3,4])
, [1., 2., 3., 4., 1., 2., 3., 4., 1., 2., 3., 4.], a.repeat(3)
, [1,1,1,2,2,2,3,3,3,4,4,4], 4 x 3, b = a.reshape(4,1).repeat(1,3).flatten()
, b = a.reshape(4,1).repeat(1,3).view(-1)
]