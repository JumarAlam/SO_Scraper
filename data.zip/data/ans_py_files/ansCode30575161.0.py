id = 30575161.0
[maxSize = 480
-- find the smaller dimension, and resize it to maxSize (while keeping aspect ratio)
local iW = input:size(3)
local iH = input:size(2)
if iW &lt; iH then
   input = image.scale(input, maxSize, maxSize * iH / iW)
else
   input = image.scale(input, maxSize * iW / iH, maxSize)
end
]