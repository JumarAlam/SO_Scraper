id = 35495926.0
[require 'nn'
torch.getmetatable('nn.Module').printTry = function() print('PrintTry') end

perceptron = nn.Sequential()
perceptron:printTry()
]