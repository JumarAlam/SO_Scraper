id = 36896347.0
[import numpy
import Image
import lutorpy as lua

getImage = numpy.asarray(Image.open("image.jpg"))
a = torch.fromNumpyArray(getImage)

# now you can use your image as torch Tensor
# for example: use SpatialConvolution from nn to process the image
require("nn")
n = nn.SpatialConvolution(1,16,12,12)
res = n._forward(a)
print(res._size())

# convert back to numpy array
output = res.asNumpyArray()
]