id = 39048688.0
[def depthconcat(inputs):
    concat_dim = 3
    shapes = []
    for input_ in inputs:
        shapes.append(tf.to_float(tf.shape(input_)[:3]))
    shape_tensor = tf.pack(shapes)
    max_dims = tf.reduce_max(shape_tensor, 0)

    padded_inputs = []
    for idx, input_ in enumerate(inputs):
        mean_diff = (max_dims - shapes[idx])/2.0
        pad_low = tf.floor(mean_diff)
        pad_high = tf.ceil(mean_diff)
        paddings = tf.to_int32(tf.pack([pad_low, pad_high], axis=1))
        paddings = tf.pad(paddings, paddings=[[0, 1], [0, 0]])
        padded_inputs.append(tf.pad(input_, paddings))

     return tf.concat(concat_dim, padded_inputs, name=name)
]