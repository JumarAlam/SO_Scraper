id = 44739093.0
[data=torch.floor(torch.rand(5,3,2)*100):float()
reordered_data=data:view(5,-1)

perm=torch.randperm(5);
perm_rep=torch.repeatTensor(perm,5,1):transpose(1,2)

indexes=torch.range(1,5);
indexes_rep=torch.repeatTensor(indexes,5,1)

permutation_matrix=indexes_rep:eq(perm_rep):float()
permuted=permutation_matrix*reordered_data

print("perm")
print(perm)
print("before permutation")
print(data)
print("after permutation")
print(permuted:view(5,3,2))
, data, perm]