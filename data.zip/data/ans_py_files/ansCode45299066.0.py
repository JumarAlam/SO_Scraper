id = 45299066.0
[np.resize, M = 3 # number of rows for output
np.resize(a,(M,a.shape[1]))
, np.take, np.take(a,np.arange(M)%a.shape[0],axis=0) # with np.take
a[np.arange(M)%a.shape[0]]                # with indexing
, In [91]: a = np.random.randint(0,9,(2000,4000))

In [92]: M = 3000

In [93]: %timeit np.resize(a,(M,a.shape[1]))
10 loops, best of 3: 24.1 ms per loop

In [94]: %timeit np.take(a,np.arange(M)%a.shape[0],axis=0)
100 loops, best of 3: 16.2 ms per loop

In [95]: %timeit a[np.arange(M)%a.shape[0]]
100 loops, best of 3: 15.2 ms per loop
]