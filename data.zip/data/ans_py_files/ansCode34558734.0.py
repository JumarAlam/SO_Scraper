id = 34558734.0
[Lua, type(), type('Hello world')                    == 'string'
type(3.14)                             == 'number'
type(true)                             == 'boolean'
type(nil)                              == 'nil'
type(print)                            == 'function'
type(coroutine.create(function() end)) == 'thread'
type({})                               == 'table'
type(torch.Tensor())                   == 'userdata'
, torch.Tensor, torch, t = torch.Tensor()
type(t)       == 'userdata' # Because the class was written in C
torch.type(t) == 'torch.DoubleTensor'
# or
t:type()      == 'torch.DoubleTensor'
, Torch, Lua, local A = torch.class('ClassA')
function A:__init(val)
    self.val = val
end

local B, parent = torch.class('ClassB', 'ClassA')
function B:__init(val)
    parent.__init(self, val)
end

b = ClassB(5)
type(b)       == 'table' # Because the class was written in Lua
torch.type(b) == 'ClassB'
b:type() # exception; Custom Torch classes have no :type() method by defauld
]