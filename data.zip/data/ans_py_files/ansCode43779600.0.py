id = 43779600.0
[Network.parameters(), parameters, parameters, Network, parameters, network = Network()
optimizer = optim.SGD(network.parameters(), lr=0.001, momentum=0.9)
, optimizer = optim.SGD(Network().parameters(), lr=0.001, momentum=0.9)
]