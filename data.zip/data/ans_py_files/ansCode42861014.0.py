id = 42861014.0
[a, and, b, or, a, b]