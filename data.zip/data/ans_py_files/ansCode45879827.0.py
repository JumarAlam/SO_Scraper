id = 45879827.0
[FloatTensor, DoubleTensor, ByteTensor, model(data), dataset, FloatTensor, model(data), data, ByteTensor]