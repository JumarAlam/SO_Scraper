id = 40147667.0
[f:lines(), line:split(' '), tonumber(val), &lt;18, 12, &lt;20, fid = io.open(sup_filename, "rb")
while true do
  local bytes = fid:read(1)
  if bytes == nil then break end -- EOF
  local st = bytes[0]
  print(st)
end

fid:close()
, :split(), lines()]