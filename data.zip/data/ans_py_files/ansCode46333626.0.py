id = 46333626.0
[result = storage_res-data;, `for(size_t i=0;i&lt;m1*n1; ++i)
   result[i]=storage_res-data[i];`
]