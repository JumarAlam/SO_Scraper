id = 45201302.0
[torch[cpuType], torch.cpuType, cpuType, DoubleTensor, FloatTensor, HalfTensor, torch.DoubleTensor, torch.FloatTensor, torch.HalfTensor, if cpuType == 'torch.DoubleTensor' then
    batch = torch.DoubleTensor(sz, nCrops, table.unpack(imageSize))
elseif cpuType == 'torch.FloatTensor' then
    batch = torch.FloatTensor(sz, nCrops, table.unpack(imageSize))
elseif cpuType == 'torch.HalfTensor' then
    batch = torch.HalfTensor(sz, nCrops, table.unpack(imageSize))
]