id = 31192847.0
[[-1,1], [0.9], threshold, [-0.35], -0.35, threshold]