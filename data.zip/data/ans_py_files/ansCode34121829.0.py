id = 34121829.0
[Not updating your shell profile.
You might want to
add the following lines to your shell profile:

. /Users/myusername/torch/install/bin/torch-activate
]