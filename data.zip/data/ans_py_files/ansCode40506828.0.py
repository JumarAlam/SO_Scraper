id = 40506828.0
[indicies = torch.LongTensor{1,7,5}
one_hot = torch.eye(10):index(1, indicies)
]