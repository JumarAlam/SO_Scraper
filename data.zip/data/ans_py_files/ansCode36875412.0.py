id = 36875412.0
[local my_vector = nn.reshape(vector_size, original_vector)
]