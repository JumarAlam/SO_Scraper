id = 46378697.0
[nn.Module, torch.nn.optim.Optimizer, encoder_optimizer = optim.Adam(encoder.parameters(), lr=learning_rate)
decoder_optimizer = optim.Adam(decoder.parameters(), lr=learning_rate) 
, nn.Module, nets = [encoder, decoder]
parameters = set()
for net in nets:
    parameters |= set(net.parameters())
, |]