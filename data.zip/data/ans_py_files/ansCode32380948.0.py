id = 32380948.0
[local command = table.concat(arg, ' ', -1, #arg)
, local mod_arg = { }
for k, v in pairs(arg) do
    if v:find"'" then
      mod_arg[k] = '"'..v..'"'
    elseif v:find'[%s$`&lt;|#]' then
      mod_arg[k] = "'"..v.."'"         
    else
      mod_arg[k] = v
    end
end 
local command = table.concat(mod_arg, ' ', -1, #mod_arg)
print(command)
]