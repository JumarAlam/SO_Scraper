id = 35259902.0
[:sub, x = torch.Tensor(5, 6):zero()
 x
 0 0 0 0 0 0
 0 0 0 0 0 0
 0 0 0 0 0 0
 0 0 0 0 0 0
 0 0 0 0 0 0
[torch.DoubleTensor of dimension 5x6]

y = x:sub(2,4):fill(1) -- y is sub-tensor of x:
 y                    -- dimension 1 starts at index 2, ends at index 4
 1  1  1  1  1  1
 1  1  1  1  1  1
 1  1  1  1  1  1
[torch.DoubleTensor of dimension 3x6]

 x                    -- x has been modified!
 0  0  0  0  0  0
 1  1  1  1  1  1
 1  1  1  1  1  1
 1  1  1  1  1  1
 0  0  0  0  0  0
[torch.DoubleTensor of dimension 5x6]
, y, x, z = torch.Tensor(4):zero()
x = z:sub(1, 2)
y = z:sub(3, 4)
x[1] = 2
y[2] = 8
print(z)
,  2
 0
 0
 8
[torch.DoubleTensor of size 4]
]