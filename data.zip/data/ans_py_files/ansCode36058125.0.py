id = 36058125.0
[function repeatNoCopy(tensor, k)
    local tens_size = tensor:size():totable()
    return torch.expand(tensor:view(1, unpack(tens_size)), k, unpack(tens_size))
end

A = torch.rand(3, 2, 5)
B = torch.rand(5, 4)
B_rep = repeatNoCopy(B, 3)

result = torch.bmm(A, B_rep)

print(result)
 [torch.DoubleTensor of size 3x2x4]
]