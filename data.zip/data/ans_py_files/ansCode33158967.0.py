id = 33158967.0
[data[5],  -- matrix-matrix operation: result is a 1x1 tensor
 local tmp = w * data[{{5}}]:t()
, w,  -- dot prod between 1D tensors: result is a number
 local tmp = w:squeeze() * data[5]
]