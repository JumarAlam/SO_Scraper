id = 30818191.0
[predictionValue*targetValue &lt; 1, targetValue = 1, targetValue = -1, output_layer_number = 1, u, v, C(u,v) = cosine(u, v) = (u / |u|) x (v / |v|)
, dC/du, dC/dv]