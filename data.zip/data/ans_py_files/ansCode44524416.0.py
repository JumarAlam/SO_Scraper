id = 44524416.0
[state, config, beta1, beta2]