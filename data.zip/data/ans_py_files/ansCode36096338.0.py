id = 36096338.0
[--------------------------------------------------------------------------------
-- Python-like zip() iterator
--------------------------------------------------------------------------------

function zip(...)
  local arrays, ans = {...}, {}
  local index = 0
  return
    function()
      index = index + 1
      for i,t in ipairs(arrays) do
        if type(t) == 'function' then ans[i] = t() else ans[i] = t[index] end
        if ans[i] == nil then return end
      end
      return unpack(ans)
    end
end

--------------------------------------------------------------------------------
-- Example use:
--------------------------------------------------------------------------------

a = {'a','b','c','d'}
b = {3,2,1}
c = {7,8,9,10,11}

for a,b,c,line in zip(a,b,c,io.lines(arg[0])) do
  print(a,b,c,line)
end

print '\n--- Done! ---'
]