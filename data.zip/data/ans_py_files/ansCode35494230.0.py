id = 35494230.0
[printTry, perceptron, Module, Module.lua, nn.Sequential, function Module:printTry()
  print("printTry()")
end
]