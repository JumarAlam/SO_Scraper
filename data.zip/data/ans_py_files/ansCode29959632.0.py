id = 29959632.0
[sudo port -f deactivate jpeg
sudo port install libjpeg-turbo
]