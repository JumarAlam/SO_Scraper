id = 32995278.0
[loadfile, local TempFunc = loadfile "torch_script.lua"
TempFunc(input_parameter1, input_parameter2)
]