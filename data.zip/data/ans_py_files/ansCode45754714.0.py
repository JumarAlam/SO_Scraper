id = 45754714.0
[transforms.ToTensor(), transform.Scale((32, 32)), Scale::__call__(self, img), Scale, PIL.Image, Tensor, transform = transforms.Compose(
[transforms.ToTensor(),
 transforms.Scale((32,32)),
 transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])
, transform = transforms.Compose([transforms.Scale((32,32)),
                                transforms.ToTensor(),
                                transforms.Normalize((0.5, 0.5, 0.5), 
                                                     (0.5, 0.5, 0.5))])
]