id = 29436069.0
[images:resize(...)
, images.resize(...)
, images:resize(...), images.resize(images, ...)]