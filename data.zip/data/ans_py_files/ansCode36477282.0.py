id = 36477282.0
[p.getOutputStream(),     Process p = Runtime.getRuntime().exec(execstr);
    BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));
    OutputStream ops = p.getOutputStream();
    ops.write("echo hello world".getBytes());
    ops.close();            

    while ((line = input.readLine()) != null) 
    {
       System.out.println(line);
    }
    input.close();
]