id = 45124612.0
[ i = [2, 1, 0, 3]
 a = np.array([[5, 2, 11, 15],[5, 2, 11, 15], [5, 2, 11, 15]])
 a[:, i]

array([[11,  2,  5, 15],
       [11,  2,  5, 15],
       [11,  2,  5, 15]])
,  i = torch.LongTensor([2, 1, 0, 3])
 a = torch.Tensor([[5, 2, 11, 15],[5, 2, 11, 15], [5, 2, 11, 15]])
 a[:,i]
, a[&lt;LongTensor], a[&lt;ByteTensor],  i = [2, 1, 0, 3]
 a = torch.Tensor([[5, 2, 11, 15],[5, 2, 11, 15], [5, 2, 11, 15]])
 np_a = a.numpy()
 np_a = np_a[:,i]
 a = torch.from_numpy(np_a)
 a

 11   2   5  15
 11   2   5  15
 11   2   5  15
[torch.FloatTensor of size 3x4]
, def hacky_permute(a, i, dim):
    a = torch.transpose(a, 0, dim)
    a = a[i]
    a = torch.transpose(a, 0, dim)
    return a
,  i = torch.LongTensor([2, 1, 0, 3])
 a = torch.Tensor([[5, 2, 11, 15],[5, 2, 11, 15], [5, 2, 11, 15]])
 a = hacky_permute(a, i, dim=1)
 a

 11   2   5  15
 11   2   5  15
 11   2   5  15
[torch.FloatTensor of size 3x4]
,  i = torch.LongTensor([2, 1, 0, 3])
 a = torch.Tensor([[5, 2, 11, 15],[5, 2, 11, 15], [5, 2, 11, 15]])
 a[:,i]

 11   2   5  15
 11   2   5  15
 11   2   5  15
[torch.FloatTensor of size 3x4]
]