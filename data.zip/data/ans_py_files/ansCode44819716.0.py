id = 44819716.0
[append, results, result = []
...

result.append(prediction) # inside some loop

...

result = np.array(result)
]