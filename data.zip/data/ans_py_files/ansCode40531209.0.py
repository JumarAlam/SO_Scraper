id = 40531209.0
[__index, __index__, __index__, __index, type(v) == "number", false, __index, local torch = require("torch")

do 
    Dataset = torch.class("Dataset")

    function Dataset:__init(i, t)
        self.inputs = i
        self.targets = t
    end

function Dataset.__index__(t, v)
    if type(v) == "number" then
        local tbl =  {
            t.inputs[v],
            t.targets[v]
        }
        return tbl, true
    else
        return false
    end
end

local dset = Dataset({0, 1, 1, 0}, {1, 1, 1, 0})
dset[1] -- {0, 1}
]