id = 36489412.0
[net = nil
trainset = nil
testset = nil
pred = nil
inputGrad = nil
criterion = nil

collectgarbage()
]