id = 43379668.0
[findFile, wc -L 'findFile' | cut -f1 -d, 53, local maxPathLength = tonumber(sys.fexecute(wc .. " -L '"
                                            .. findFile .. "' |"
                                            .. cut .. " -f1 -d' '")) + 1
, nil +1, path_local]