id = 45620673.0
[.., ., 447, function isSubdir(path)
    noError, result = pcall(isDir, path)
    if noError then return result else return false end
end

-- Credit: https://stackoverflow.com/a/3254007/1830334
function isDir(path)
    local f = io.open(path, 'r')
    local ok, err, code = f:read(1)
    f:close()
    return code == 21
end

function getSubdirs(rootDir)
    subdirs = {}
    counter = 0
    local dirs = paths.dir(rootDir)
    table.sort(dirs)
    for i = 1, #dirs do
        local dir = dirs[i]
        if dir ~= nil and dir ~= '.' and dir ~= '..' then
            local path = rootDir .. '/' .. dir
            if isSubdir(path) then
                counter = counter + 1
                subdirs[counter] = path
            end
        end
    end
    return subdirs
end

local subdirs = getSubdirs('/your/root/path/here')
print(subdirs)
]