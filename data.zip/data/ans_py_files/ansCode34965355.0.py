id = 34965355.0
[optim, optimState = { 
learningRate = 0.001,
weightDecay = 0,
momentum = 0.9,
learningRateDecay = 0 
}
, optim.method, optim.method(func, x, optimState)
]