id = 24101297.0
[typename, template, typename, template, typename, template, template&lt;class T void f_tmpl () { T::foo * x; /* &lt;-- (A) */ }
, T, T, struct X { typedef int       foo;       }; /* (C) -- */ f_tmpl&lt;X ();
struct Y { static  int const foo = 123; }; /* (D) -- */ f_tmpl&lt;Y ();
, template&lt;class T void g_tmpl () {
   SomeTrait&lt;T::type                   foo; // (E), ill-formed
   SomeTrait&lt;T::NestedTrait&lt;int::type bar; // (F), ill-formed
   foo.data&lt;int ();                         // (G), ill-formed    
}
, SomeTrait&lt;T, T, SomeTrait&lt;T, SomeTrait&lt;T, SomeTrait&lt;T, g_tmpl, template&lt;class T void g_tmpl () {
   typename SomeTrait&lt;T::type foo;                            // (G), legal
   typename SomeTrait&lt;T::template NestedTrait&lt;int::type bar; // (H), legal
   foo.template data&lt;int ();                                  // (I), legal
}
, typename, template, template, typename, template, Some C++ Developer, namespace N {
  template&lt;class T
  struct X { };
}
,          N::         X&lt;int a; // ...  legal
typename N::template X&lt;int b; // (K), legal
typename template    X&lt;int c; // (L), ill-formed
, typename, template, typename, template, typename,                     // .------- the base-specifier-list
  template&lt;class T // v
  struct Derived      : typename SomeTrait&lt;T::type /* &lt;- ill-formed */ {
    ...
  };
,   struct Base {
    template&lt;class T
    struct type { };
  };

  struct Derived : Base {
    using Base::template type; // ill-formed
    using Base::type;          // legal
  };
]