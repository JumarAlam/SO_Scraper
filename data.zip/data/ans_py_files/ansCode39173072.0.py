id = 39173072.0
[z = {}

for i=1,10 do

  z[i] = {}
  for j=1,10 do
    z[i][j] = torch.Tensor()
  end
end
]