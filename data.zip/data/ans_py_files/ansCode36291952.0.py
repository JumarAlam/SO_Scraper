id = 36291952.0
[sliced_dataset = dataset:index(1, positive_mask:nonzero():squeeze())
]