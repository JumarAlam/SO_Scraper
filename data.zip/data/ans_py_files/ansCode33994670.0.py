id = 33994670.0
[matrix

matrix:sub(2,3,2,3)

z = torch.Tensor({{78,66},{45,21}})

matrix:sub(2,3,2,3):copy(z)
]