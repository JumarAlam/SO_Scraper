id = 25027190.0
[import time

for x in range(0,3):
    someFunction()

def someFunction():
    start = time.time()
    while (time.time() - start &lt; 5):
        # do your normal function

    return;
]