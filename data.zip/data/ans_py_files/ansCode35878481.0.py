id = 35878481.0
[updateOutput, updateGradInput]