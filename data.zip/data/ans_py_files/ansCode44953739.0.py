id = 44953739.0
[pycrypto, pycrypto, pip install -U steem
, pip help install
, -U, -U, --upgrade        Upgrade all specified packages to the newest available
                     version. The handling of dependencies depends on the
                     upgrade-strategy used.
, steem, -U]