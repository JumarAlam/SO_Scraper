id = 45123611.0
[local Blah = torch.class('Blah'), do 
end 
, class 'Blah', do-end, local, -- for naming convenience
]