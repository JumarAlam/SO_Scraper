id = 38714546.0
[net1.updateGradInput = function(self, inp, out) end
net1.accGradParameters = function(self,inp, out) end
, gradient1 = cr1:backward(out1, target1)]