id = 35688733.0
[th require 'nngraph'
th conv1 = nn.SpatialConvolution(3, 96, 5, 5, 1, 1, 2, 2)()
th model = nn.gModule({conv1},{conv1})
th x = torch.rand(3,20,20)
th y = model:forward(x)
th y:size()

96
20
20
[torch.LongStorage of size 3]
]