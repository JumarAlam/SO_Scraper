id = 35971079.0
[libcufft.so, SET(PROJECT_LINK_LIBS libcufft.so )
LINK_DIRECTORIES(/net/wanggu/spectral-lib/cuda)
]