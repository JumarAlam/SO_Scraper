id = 45393044.0
[ sr=scores:view(-1,scores:size(1)*scores:size(2))
 val,id=sr:sort()
 --val is a row vector with the values stored in increasing order
 --id will be the corresponding index in sr
 --now you can slice val and id from the end to find the N values you want, then you can recover the original index in the scores matrix simply with
 col=(index-1)%scores:size(2)+1
 row=math.ceil(index/scores:size(2))
]