id = 45777165.0
[nn.Normalize, PartialNormalize.lua, local PartialNormalize, parent = torch.class('nn.PartialNormalize', 'nn.Normalize')
--now basically you need to override the funcions __init, updateOutput and updateGradInput from the parent class (I dont think there is a need to override other functions, but you shoud make check.)
-- you can find the code for nn.Normalize in  &lt;your_install_path/install/share/lua/5.1/nn/Normalize.lua
-- the interval [first_index, last_index] determines which parts  from your input vector you want to be normalized.

function PartialNormalize:__init(p,eps,first_index,last_index)
  parent.__init(self) 
  self.first_index=first_index
  self.last_index=last_index
end


function PartialNormalize:updateOutput(input)
  --In the parent class, this just returns the normalized part 
  -- just modify this function so that it returns the normalized part from self.first_index to self.last_index, and that it just passes the other elements through
end 

function PartialNormalize:updateGradInput(input, gradOutput)
    -- make appropriate modifications to the gradient function: gradient for elements from self.first_index to self.last_index is computed just as in the parent class,
    -- while the gradient for other elements is just 1 everywhere
end

   -- I don't think other functions from the parent class need overriding, but make sure just in case
]