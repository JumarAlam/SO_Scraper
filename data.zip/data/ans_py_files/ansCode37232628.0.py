id = 37232628.0
[HDF5Group:_writeData, ffi.lua, label = {'a', 'b','c','d'}
]