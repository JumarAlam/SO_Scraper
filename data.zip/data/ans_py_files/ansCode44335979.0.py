id = 44335979.0
[L, loss(input, target) = ClassNLLCriterion(input, target) * K
, updateGradInput, updateGradInput[ClassNLLCriterion](input, target) * K + ClassNLLCriterion(input, target) * dK/dinput
, ClassNLLCriterion, updateGradInput, updateOutput]