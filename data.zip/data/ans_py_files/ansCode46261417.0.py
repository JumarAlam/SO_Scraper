id = 46261417.0
[d, training_data, d, d = x[0:10000].clone()
l = y[0:10000].clone()
, clone, torch.Tensor(), d, l, training_data, labels]