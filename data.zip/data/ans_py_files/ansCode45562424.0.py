id = 45562424.0
[nn.Linear(...), __init__, .cuda(), net.forward(...), train, self.network.cuda(), net.forward(...), x.size() &lt;= Linear --  (Batch_size,  Features), def forward(self, x):
    x = F.relu(self.input_layer(x))
    x = F.dropout(F.relu(self.hidden_layer(x)),training=self.training)
    x = self.output_layer(x)
    return x
]