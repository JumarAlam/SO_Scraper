id = 29335566.0
[dataset[i] = {dnaseIsignals[i-1], dnaseIsignals[i-1]} 
]