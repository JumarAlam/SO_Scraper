id = 43128647.0
[
conda install pytorch torchvision -c soumith
]