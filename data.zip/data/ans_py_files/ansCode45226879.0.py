id = 45226879.0
[print([trainset[i] for i in range(10)])
, __getitem__(), trainset[i], trainset.__getitem__(i), __getitem__(), __getitem__(), trainset[2:10], trainset.__getitem__(slice(2, 10)), __getitem__, __getitem__, def __getitem__(self, index):
    if self.train:
        img, target = self.train_data[index], self.train_labels[index]
    else:
        img, target = self.test_data[index], self.test_labels[index]

    # doing this so that it is consistent with all other datasets
    # to return a PIL Image
    img = Image.fromarray(img)

    if self.transform is not None:
        img = self.transform(img)

    if self.target_transform is not None:
        target = self.target_transform(target)

    return img, target
]