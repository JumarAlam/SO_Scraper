id = 38866351.0
[require 'nn'
N = 4
aaaTensor = torch.randn(N,1)
bbbTensor = torch.randn(N,1)
thisTable = {aaaTensor, bbbTensor}
cosine = nn.CosineDistance()
cosine:forward{aaaTensor, bbbTensor}
]