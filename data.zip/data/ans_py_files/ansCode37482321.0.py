id = 37482321.0
[CameraManager camManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
String cameraId = camManager.getCameraIdList()[0]; // Usually front camera is at 0 position and back camera is 1.
camManager.setTorchMode(cameraId, true);
]