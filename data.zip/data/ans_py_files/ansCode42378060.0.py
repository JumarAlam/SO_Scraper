id = 42378060.0
[sudo bash /torch/update.sh]