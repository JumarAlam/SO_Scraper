id = 37491887.0
[local gm = require 'graphicsmagick'
local img = gm.Image()
local ok = pcall(img.fromString, img, body)
img = img:toTensor('float', 'RGB', 'DHW')
, local body, code = http.request(image_url)
, body, pcall]