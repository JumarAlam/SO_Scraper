id = 39750422.0
[undefined symbol: luaL_setfuncs, ./clean.sh]