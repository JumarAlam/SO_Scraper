id = 34411404.0
[B,  1  1  1
 2  2  2
 3  3  3
[torch.DoubleTensor of size 3x3]
, local A = torch.Tensor{{1,2,3},{4,5,6},{7,8,9}}
local B = torch.Tensor{1,2,3}
local C = A:cmul(B:view(3,1):expand(3,3))
]