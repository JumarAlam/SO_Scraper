id = 46001698.0
[cuda, x, .cuda(), x = V(centre_crop(img).unsqueeze(0), volatile=True).cuda()
]