id = 36459293.0
[set, unique(), function vector_unique(input_table)
    local unique_elements = {} --tracking down all unique elements
    local output_table = {} --result table/vector

    for _, value in ipairs(input_table) do
        unique_elements[value] = true
    end

    for key, _ in pairs(unique_elements) do
        table.insert(output_table, key)
    end

    return output_table
end
]