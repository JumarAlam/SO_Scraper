id = 29257879.0
[input, output, Tensor, input, dim, Tensor, x001,x002,x003,x004,x005,x006,x007,x008,x009,x010,x011,x012,x013,x014,x015,x016,x017,x018,label
, local csv2tensor = require 'csv2tensor'

local inputs = csv2tensor.load("data.csv", {exclude={"label"}})
local labels = csv2tensor.load("data.csv", {include={"label"}})

local dataset = {}

for i=1,inputs:size(1) do
  dataset[i] = {inputs[i], torch.Tensor{labels[i]}}
end

dataset.size = function(self)
  return inputs:size(1)
end
, -- ...
trainer:train(dataset)
]