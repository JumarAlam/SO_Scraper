id = 42939807.0
[z = x.cmul(y)
, cmul, Tensor]