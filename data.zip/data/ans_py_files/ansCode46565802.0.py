id = 46565802.0
[torch.Variable, v=torch.Variable(mytensor)
, v.data, Variable, torch.Variable]