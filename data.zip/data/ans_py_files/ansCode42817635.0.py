id = 42817635.0
[model:evaluate();

-- We assume that the image has a wrong size, place here your image loading code
img = torch.Tensor(3, 200, 200)
-- First we scale it to 3x48x48
img = image.scale(img, 48, 48, 'bilinear')
-- Then to avoid errors with the batchnorm layer we make it 4D 
-- (batchNorm expects a 4D tensor)
image = image:reshape(1, 3, 48, 48)
-- Feed the image to the network, add the :exp() if we want to retrieve the probs.
pred = model:forward(img):exp()


-- output
Columns 1 to 10
0.01 *
9.4125  9.0546  8.9142  9.0716  9.0065  9.0865  9.4289  8.7353  9.2937  9.2811

Columns 11 to 11
0.01 *
8.7152
[torch.DoubleTensor of size 1x11]
]