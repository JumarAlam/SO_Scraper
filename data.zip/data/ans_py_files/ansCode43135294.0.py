id = 43135294.0
[setmetatable(train_set, 
{
  __index = function(t, i) 
    return {t.data[i], t.label[i]}
  end
})
,  {
  __index = function(t, i) 
      return {t.data[i], t.label[i]}
  end
 }
, local my_metatable = {
  __index = function(t, i) 
     return {t.data[i], t.label[i]}
  end
}
setmetatable(train_set, my_metatable)
, __index, train_set[4], train_set[4], nil, __index, __index(train_set, 4), nil]