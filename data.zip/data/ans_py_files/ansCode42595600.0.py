id = 42595600.0
[require 'image'
require 'nn'
require 'torch'
require 'paths'

local function main()

print '== Downloading image and network'
local image_url = '/home/delpech/mnist/test/7/03079.png'
local network_url = '/home/delpech/models/snapshot_30_Model.t7'
local mean_url = '/home/delpech/models/mean.jpg'

print '== Loading network'
local net = torch.load(network_url)
net:evaluate();

print '== Loading synsets'
print 'Loads mapping from net outputs to human readable labels'
local synset_words = {}
for line in io.lines'/home/delpech/models/labels.txt' do table.insert(synset_words, line) end

print '== Loading image and imagenet mean'
local im = image.load(image_url):type('torch.FloatTensor'):contiguous();--:contiguous()
im:mul(255)
local I = image.scale(im,28,28,'bilinear'):float()


local im_mean =  image.load(mean_url):type('torch.FloatTensor'):contiguous();
im_mean:mul(255)
local Imean = image.scale(im,28,28,'bilinear'):float()

print '== Preprocessing'
for i=1,im_mean:size(1) do
    im[i]:csub(im_mean[i])
end

local _,classes = net:forward(im):sort(true);
for i=1,10 do
  print('predicted class '..tostring(i)..': ', synset_words[classes[i]])
end

end 


main()
]