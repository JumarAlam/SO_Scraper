id = 37448589.0
[t = torch.Tensor({1, 2, 3, 1, 4, 2, 2, 2, 3, 0})
frequency = t:eq(2):sum() -- frequency of 2 in t
]