id = 45206306.0
[  public Camera getCameraObject (CameraSource _camSource)
        {
            Field [] cFields = _camSource.Class.GetDeclaredFields ();
            Camera _cam = null;
            try {
                foreach (Field item in cFields) {
                    if (item.Name.Equals ("zzbNN")) {
                        Console.WriteLine ("Camera");
                        item.Accessible = true;
                        try {
                            _cam = (Camera)item.Get (_camSource);
                        } catch (Exception e) {
                            Logger.LogException (this, e);
                        }
                    }
                }
            } catch (Exception e) {
                Logger.LogException (this, e);
            }
            return _cam;
        }

        public void setFlash (bool isEnable)
        {
            try {
                isTorch = !isEnable;
                var _cam = getCameraObject (mCameraSource);
                if (_cam == null) return;
                var _pareMeters = _cam.GetParameters ();
                var _listOfSuppo = _cam.GetParameters ().SupportedFlashModes;
                _pareMeters.FlashMode = isTorch ? _listOfSuppo [0] : _listOfSuppo [3];
                _cam.SetParameters (_pareMeters);
            } catch (Exception e) {
                Logger.LogException (this, e);
            }
        }
]