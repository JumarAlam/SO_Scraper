id = 37238657.0
[rpnnode.Foo(rpnnode, input), rpnnode:Foo(input)]