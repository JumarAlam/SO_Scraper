id = 46538480.0
[out-channel, in-channel, import torch
import torch.nn.functional as F

filters = torch.autograd.Variable(torch.randn(3,1,3,3))
inputs = torch.autograd.Variable(torch.randn(1,3,10,10))
out = F.conv2d(inputs, filters, padding=1, groups=3)
, (2, 1, 3, 3), (1, 1, 3, 3), out-channel, in-channel, (4, 1, 3, 3), (5, 1, 3, 3), out-channel]