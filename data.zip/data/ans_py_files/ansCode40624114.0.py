id = 40624114.0
[/Users/you/torch/install/bin, $ cd
, $ emacs .bash_profile
, PATH=$PATH\:/Users/you/torch/install/bin ; export PATH
, $ source .bash_profile
, /Users/you/torch/install/bin, $ echo $PATH
, echo $PATH again, th, . /Users/jb/torch/install/bin/torch-activate]