id = 46529862.0
[1x1x42x42, nn.Conv2D, nn.Linear, input = input.squeeze(), nn.Linear, batch_size x feat_dim]