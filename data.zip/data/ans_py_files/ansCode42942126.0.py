id = 42942126.0
[cmul, mul, import torch

x = torch.Tensor([2, 3])
y = torch.Tensor([2, 1])
z = torch.mul(x, y)
print(z)
]