id = 29474911.0
[string.match, io.lines, -- script.lua
local t, patt = {}, ("(%w+)%s+"):rep(5).."(%w+)"
for line in io.lines() do
  if not line:find("^chromNameA") then
    table.insert(t, {line:match(patt)})
  end
end
print(#t, t[1][1], t[1][6]) -- prints `5 chr22 16678717`

-- file.txt
chromNameA  startA  endA    chromNameB  startB  endB
chr22   16867980    16868130    chr22   16669675    16678717
chr22   16867980    16868130    chr22   16685348    16701095
chr22   16867980    16868130    chr22   16723869    16739035
chr22   16867980    16868130    chr22   16748016    16750787
chr22   16867980    16868130    chr22   16750788    16755877

-- execution: lua script.lua &lt;file.txt
, lua script.lua &lt;file.txt]