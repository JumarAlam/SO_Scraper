id = 33872791.0
[torch.Tensor, :sub, :select, __index, torch.mean]