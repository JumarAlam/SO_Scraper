id = 38947109.0
[nobody, chown -R nobody:nogroup openresty_project/
chmod -R 755 openresty_project/
, nginx.conf, user myuser mygroup;
]