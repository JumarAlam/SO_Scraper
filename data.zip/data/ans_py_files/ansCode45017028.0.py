id = 45017028.0
[add_, sub_, w.data.sub_(f.grad.data * alpha)
]