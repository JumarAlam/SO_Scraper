id = 30416207.0
[require "nn", init.lua, require('libnn'), init.c, luaopen_libnn, libnn.so, require, MSECriterion, nn_FloatMSECriterion_init(L), nn_DoubleMSECriterion_init(L), generic/MSECriterion.c, float, double, static void nn_(MSECriterion_init)(lua_State *L)
{
  luaT_pushmetatable(L, torch_Tensor);
  luaT_registeratname(L, nn_(MSECriterion__), "nn");
  lua_pop(L,1);
}
, torch.FloatTensor, torch.DoubleTensor, nn, static const struct luaL_Reg nn_(MSECriterion__) [] = {
  {"MSECriterion_updateOutput", nn_(MSECriterion_updateOutput)},
  {"MSECriterion_updateGradInput", nn_(MSECriterion_updateGradInput)},
  {NULL, NULL}
};
, luajit -lnn
 print(torch.Tensor().nn.MSECriterion_updateOutput)
function: 0x40921df8
 print(torch.Tensor().nn.MSECriterion_updateGradInput)
function: 0x40921e20
, input.nn.MSECriterion_updateOutput(self, input, target), static int nn_(MSECriterion_updateOutput)(lua_State *L)]