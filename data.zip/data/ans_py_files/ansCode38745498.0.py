id = 38745498.0
[nn.Container, container = nn.Container()
container:add(gMod)
container:add(gModTest)
params, gradParams = container:getParameters()
]