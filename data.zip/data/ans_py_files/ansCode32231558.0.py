id = 32231558.0
[torch.nn, nn.Parallel, gradOutput, local first_part = nn.Parallel(1,2)
--                               ^
--                 Merging on the 2nd dimension; 
--       Chunks of splitted gradOutput will not be contiguous
, nn.Sum, gradOutput, Sum_nc, _ = torch.class('nn.Sum_nc', 'nn.Sum')
function Sum_nc:updateGradInput(input, gradOutput)
    local size = input:size()
    size[self.dimension] = 1
    -- modified code:
    if gradOutput:isContiguous() then
        gradOutput = gradOutput:view(size) -- doesn't work with non-contiguous tensors
    else
        gradOutput = gradOutput:resize(size) -- slower because of memory reallocation and changes gradOutput
        -- gradOutput = gradOutput:clone():resize(size) -- doesn't change gradOutput; safer and even slower
    end
    --
    self.gradInput:resizeAs(input)
    self.gradInput:copy(gradOutput:expandAs(input))
    return self.gradInput
end 

[...]

sums = nn.Sequential()
sums:add(nn.Sum_nc(3)) -- &lt;- will use torch.view
sums:add(nn.Sum_nc(3)) -- &lt;- will use torch.resize
]