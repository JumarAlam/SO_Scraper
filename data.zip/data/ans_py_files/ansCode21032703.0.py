id = 21032703.0
[__init__, __init__, def __init__(self, arg1, arg2):
, instance = OurClass('arg1', 'arg2')
, __init__, __init__, self.arg1 = arg1
self.arg2 = arg2
, instance = OurClass('arg1', 'arg2')
print instance.arg1
arg1
, __init__]