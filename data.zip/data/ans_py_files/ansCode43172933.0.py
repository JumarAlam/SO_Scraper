id = 43172933.0
[yum install postgresql-devel
, yum install lua-sql-postgresql
]