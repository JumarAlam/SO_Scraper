id = 43883143.0
[torch.FloatTensor, torch.cuda.FloatTensor, .cuda(), torch.Tensor.cuda()]