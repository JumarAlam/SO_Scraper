id = 41515774.0
[nn.Container():add(enc):add(dec):getParameters(), torch.cat(enc:getParameters(), dec:getParameters())]