id = 33263453.0
[do
 local Blah = torch.class('Blah')
 function Blah:__init() end
end

blah = Blah()
]