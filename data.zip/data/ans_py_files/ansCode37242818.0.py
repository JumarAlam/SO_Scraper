id = 37242818.0
[3D or 4D (batch mode) tensor, t.data[i]
, t.data[i]:view(1, 28, 28)
]