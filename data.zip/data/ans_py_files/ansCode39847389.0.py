id = 39847389.0
[public class fragment_qrscan extends myFragment {

    SurfaceView cameraPreview;
    private CameraSource mCameraSource;
    private Button btnLight;
    boolean lightOn = false;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_qrscan, container, false);

        cameraPreview = (SurfaceView) view.findViewById(R.id.camera_preview);
        btnLight = (Button) view.findViewById(R.id.btnLight);

        btnLight.setOnClickListener(
                new View.OnClickListener() {
                    public void onClick(View v) {
                        btnLightClicked();
                    }
                }
        );

        createCameraSource(true, false);

        return view;
    }

    private void btnLightClicked() {

       if (!lightOn) {
            mCameraSource.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);
           lightOn = true;

       }
        else {
           mCameraSource.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
           lightOn = false;
       }
    }

    @SuppressLint("InlinedApi")
    private void createCameraSource(boolean autoFocus, boolean useFlash) {
        Context context = getActivity().getApplicationContext();
        BarcodeDetector barcodeDetector = new BarcodeDetector.Builder(context).build();
        CameraSource.Builder builder = new CameraSource.Builder(getActivity().getApplicationContext(), barcodeDetector)
                .setFacing(CameraSource.CAMERA_FACING_BACK)
                .setRequestedPreviewSize(1600, 1024)
                .setRequestedFps(15.0f);
        // make sure that auto focus is an available option
        if (Build.VERSION.SDK_INT = Build.VERSION_CODES.ICE_CREAM_SANDWICH) {
            builder = builder.setFocusMode(
                    autoFocus ? Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE : null);
        }

        mCameraSource = builder
                .setFlashMode(useFlash ? Camera.Parameters.FLASH_MODE_TORCH : null)
                .build();

    cameraPreview.getHolder().addCallback(new SurfaceHolder.Callback() {
        @Override
        public void surfaceCreated(SurfaceHolder holder) {
            try {
                if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.CAMERA}, 1);
                }

                mCameraSource.start(cameraPreview.getHolder());

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

        }

        @Override
        public void surfaceDestroyed(SurfaceHolder holder) {

            mCameraSource.stop();
        }
    });

    barcodeDetector.setProcessor(new Detector.Processor&lt;Barcode() {
        @Override
        public void release() {

        }

        @Override
        public void receiveDetections(Detector.Detections&lt;Barcode detections) {

            final SparseArray&lt;Barcode barcodes = detections.getDetectedItems();
            if (barcodes.size() 0) {
                Log.i("myStuff",String.valueOf(barcodes.valueAt(0).displayValue));
            }
        }
    });

    }
}
]