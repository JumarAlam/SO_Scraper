id = 36534297.0
[a = a:repeatTensor(1, 3):reshape(9, 3)
]