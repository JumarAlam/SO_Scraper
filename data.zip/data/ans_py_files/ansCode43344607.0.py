id = 43344607.0
[a.view(1,5)
Out: 

 1  2  3  4  5
[torch.FloatTensor of size 1x5]
]