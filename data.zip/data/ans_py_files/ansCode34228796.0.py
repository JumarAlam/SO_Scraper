id = 34228796.0
[y = x[{{1, 1}, {}, {}}]
, y = x[{{1, 1}}]

(1,.,.) = 
  1  1  1  1
  1  1  1  1
  1  1  1  1
  1  1  1  1
[torch.DoubleTensor of size 1x4x4]
]