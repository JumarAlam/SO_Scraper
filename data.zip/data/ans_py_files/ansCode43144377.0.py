id = 43144377.0
[h_desired, h_desired - h_current, delta_i=(y_predicted_i - y_observed_i), k, b, y_predicted_i = k * x_i + b]