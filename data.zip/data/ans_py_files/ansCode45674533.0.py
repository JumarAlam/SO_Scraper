id = 45674533.0
[pip install http://download.pytorch.org/whl/torch-0.2.0.post1-cp27-none-macosx_10_7_x86_64.whl 
pip install torchvision 
# OSX Binaries dont support CUDA, install from source if CUDA is needed
, pip install torchvision, anaconda, conda, pip, pip uninstall torch
, conda install pytorch torchvision -c soumith
]