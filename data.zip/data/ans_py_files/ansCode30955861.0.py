id = 30955861.0
[-- nstates[2]*filtsize*filtsize = 64x5x5 = 1,600
model:add(nn.Reshape(nstates[2]*filtsize*filtsize))
, model:add(nn.Reshape(nstates[2]*47*47))
model:add(nn.Linear(nstates[2]*47*47, nstates[3]))
]