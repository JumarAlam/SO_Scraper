id = 30629255.0
[@=, @, *, *, A @ B, A * B, A @= B, A *= B, A = [[1, 2],    B = [[11, 12],
     [3, 4]]         [13, 14]]
, A * B = [[1 * 11,   2 * 12], 
         [3 * 13,   4 * 14]]
, A @ B  =  [[1 * 11 + 2 * 13,   1 * 12 + 2 * 14],
           [3 * 11 + 4 * 13,   3 * 12 + 4 * 14]]
, *, dot, @, # Current implementation of matrix multiplications using dot function
S = np.dot((np.dot(H, beta) - r).T,
            np.dot(inv(np.dot(np.dot(H, V), H.T)), np.dot(H, beta) - r))

# Current implementation of matrix multiplications using dot method
S = (H.dot(beta) - r).T.dot(inv(H.dot(V).dot(H.T))).dot(H.dot(beta) - r)

# Using the @ operator instead
S = (H @ beta - r).T @ inv(H @ V @ H.T) @ (H @ beta - r)
]