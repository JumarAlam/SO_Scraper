id = 43762913.0
[forward, output, charFeatures[i], charFeatures[i], charRep.output, charRep.output, charFeatures, charRep.output, a = torch.Tensor(5):zero()
b = a
a[1] = 0
-- then b is also modified
, charFeatures[i] = charRep:forward(c[i]):clone()
]