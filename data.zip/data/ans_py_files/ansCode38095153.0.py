id = 38095153.0
[X_py = {}
for s, scale in ipairs(scales) do
  X_py[s] = fromfile(('%s/x_py_%.2f.bin'):format(data_dir, scale))
end
]