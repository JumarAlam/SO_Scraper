id = 36680172.0
[torch.serialization, File:writeObject, elseif typeidx == TYPE_TORCH then
, File:isWritableObject, write, __pairs, __pairs__, torch.getmetatable, test = torch.class('test')
function test:__init()
  self.data = {}
end

function test:__pairs__(...)
    return pairs(self.data, ...)
end

function test:get_data()
  print(self.data)
end

a = test.new()
a.data = {"asdasd"}
b = torch.serialize(a)
c = torch.deserialize(b)
print(torch.typename(c))
print(c:get_data())
, test    
{
  1 : "asdasd"
}
]