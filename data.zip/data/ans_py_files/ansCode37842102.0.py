id = 37842102.0
[function rmdir(p)
  path.each(path.join(p,"*"), function(P)
    path.remove(P)
  end,{
    param = "f";   -- request full path
    delay = true;   -- use snapshot of directory
    recurse = true; -- include subdirs
    reverse = true; -- subdirs at first 
  })
  path.remove(p)
end
]