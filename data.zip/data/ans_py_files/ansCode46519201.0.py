id = 46519201.0
[autograd.Variable(torch.from_numpy(embeds[0]).float().cuda()), .float(), embeds]