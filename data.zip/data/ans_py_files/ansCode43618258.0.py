id = 43618258.0
[n, x_at_i, X = torch.Tensor(n, n):zero()
for i = 1, n do
    X[i]:narrow(1, 1, i):copy(x_at[i])
end
]