id = 37449013.0
[luarocks install https://raw.github.com/jucor/torch-distributions/master/distributions-0-0.rockspec
, require 'distributions'
mu = torch.Tensor({10, 0})
sigma = torch.eye(2)
sample = distributions.mvn.rnd(mu, sigma) -- a sample from the distribution
]