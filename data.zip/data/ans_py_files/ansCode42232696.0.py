id = 42232696.0
[apply, repeatTensor, cmul, rPr = r:view(1, N) * P * r:view(N, 1)
denominator = (1 + rPr):apply(function(x) return x^(-1) end)
delta_w:cmul(torch.repeatTensor(denominator, N, N))
]