id = 28189121.0
[require 'caffe', caffe::Net, nn, nn.Sequential, require 'loadcaffe'

local net = loadcaffe.load('net.prototxt', 'net.caffemodel')
, findModules, conv1, fc7, fc7, INNER_PRODUCT, local nodes = net:findModules('nn.Linear')
local fc7 = nodes[#nodes-1]
, fc7.weight, fc7.bias, torch.Tensor, 'fc7', local fc7
for _,m in pairs(net:listModules()) do
  if m.name == 'fc7' then
    fc7 = m
    break
  end
end
]