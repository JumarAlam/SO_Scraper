id = 40033077.0
[in_1, in_2, in_1, in_2, nil, collectgarbage]