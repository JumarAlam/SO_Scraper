id = 36699655.0
[sudo git config --global url."https://".insteadOf git://
]