id = 34831435.0
[SpatialConvolutionMM, model:add(nn.SpatialConvolutionMM(10, 10, 5, 5))]