id = 39529149.0
[ class Foo(object):
...     pass
 class_name = 'Goo'
 my_class = type(class_name, (Foo, ), {'run': lambda self, x: 2*x })
 globals()[class_name] = my_class
 g = my_class()
 pickle.dumps(g)
]