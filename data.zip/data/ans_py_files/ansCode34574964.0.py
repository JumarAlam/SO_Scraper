id = 34574964.0
[t = { 0,  -1,  -3,
      6,   5,   0,
      0.3, 0.6, 0.9 }

temp = {}
for _,n in ipairs(t) do
  if n  0 then               --keep only positives
    temp[#temp+1] = n
  end
end
table.sort(temp)              --sorting them will bring the smallest first

print('Answer',temp[1])
, t = { 0,  -1,  -3,
      6,   5,   0,
      0.3, 0.6, 0.9 }

temp = {}
for i,n in ipairs(t) do
  if n  0 then               --keep only positives
    temp[#temp+1] = { n = n, p = i}
  end
end
table.sort(temp,function(a,b) return a.n &lt; b.n end)      --sorting them will bring the smallest first

print('Answer '.. temp[1].n ..' at position '.. temp[1].p)
]