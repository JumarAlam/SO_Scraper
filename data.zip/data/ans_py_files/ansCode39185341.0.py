id = 39185341.0
[require 'nn'

x = {torch.Tensor{{1,1},{1,1}}, torch.Tensor{{2,2},{2,2}}}
y = {torch.Tensor{{3,3,3},{3,3,3}}, torch.Tensor{{4,4,4},{4,4,4}}}

res = {}
res[1] = nn.JoinTable(2):forward({nn.SelectTable(1):forward(x),nn.SelectTable(1):forward(y)})
res[2] = nn.JoinTable(2):forward({nn.SelectTable(2):forward(x),nn.SelectTable(2):forward(y)})

print(res[1])
print(res[2])
, require 'nngraph'

x = {torch.Tensor{{1,1},{1,1}}, torch.Tensor{{2,2},{2,2}}}
y = {torch.Tensor{{3,3,3},{3,3,3}}, torch.Tensor{{4,4,4},{4,4,4}}}

xi = nn.Identity()()
yi = nn.Identity()()
res = {}
--you can loop over columns here
res[1] = nn.JoinTable(2)({nn.SelectTable(1)(xi),nn.SelectTable(1)(yi)})
res[2] = nn.JoinTable(2)({nn.SelectTable(2)(xi),nn.SelectTable(2)(yi)})
module = nn.gModule({xi,yi},res)

--test like this
result = module:forward({x,y})
print(result)
print(result[1])
print(result[2])

--gives the result
th print(result)
{
  1 : DoubleTensor - size: 2x5
  2 : DoubleTensor - size: 2x5
}

th print(result[1])
 1  1  3  3  3
 1  1  3  3  3
[torch.DoubleTensor of size 2x5]

th print(result[2])
 2  2  4  4  4
 2  2  4  4  4
[torch.DoubleTensor of size 2x5]
]