id = 30679176.0
[gdb64 /bin/bash    # check your gdb configuration either it's i686 or x86_64 
run /path/to/th    # th is the torch running script to be debugged
]