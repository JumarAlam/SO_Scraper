id = 43664575.0
[conda uninstall, conda uninstall pytorch torchvision cuda80 -c soumith
, conda uninstall pytorch
pip uninstall torch
pip uninstall torch # run this command twice
]