id = 37668341.0
[m = nn.Linear(100,200)
-- copy your weights / bias into m.weight / m.bias
m.accGradParameters = function() end
-- m is a constant multiplier thing
]