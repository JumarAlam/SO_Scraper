id = 43884411.0
[maskedSelect, result=A:maskedSelect(your_byte_tensor), result=torch.cmul(A,S:gt(0))]