id = 31129029.0
[{}, {},  a = torch.Tensor(3, 3):fill(0)
     0 0 0
     0 0 0
     0 0 0

 b = torch.Tensor(3, 3)
 for i=1,3 do for j=1,3 do b[i][j] = (i - 1) * 3 + j end end
 b
     1 2 3
     4 5 6
     7 8 9

 a[{1, {}}] = b[{3, {}}]
 a
    7 8 9
    0 0 0
    0 0 0
, a[1] = b[3],  im4[{1,{},{}}] = im3[{3,{},{}}]
 im4[{3,{},{}}] = im3[{1,{},{}}]
,  im4[1] = im3[3]
 im4[3] = im3[1]
, im3, im4, im3, im4, im3, im4]