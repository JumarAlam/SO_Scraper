id = 45494388.0
[Variable, Variable, numpy array, Variable, Variable, preds, Variable, nparr = preds.data.numpy()
x = nparr[4, 4] 
, preds, Variable, preds = preds.cpu()
, nparr = preds.data.numpy()
x = nparr[4, 4]
, x, tensor, Variable,  x = preds.data[4, 4]
]