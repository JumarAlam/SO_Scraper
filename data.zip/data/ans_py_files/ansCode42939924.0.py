id = 42939924.0
[torch.legacy.nn]