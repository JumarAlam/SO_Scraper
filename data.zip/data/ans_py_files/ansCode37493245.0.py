id = 37493245.0
[brew, sudo ~/torch/install/bin/luarocks install nn]