id = 42403166.0
[net:parameters(), net:getParameters(), sgd()]