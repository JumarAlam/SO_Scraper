id = 44637051.0
[target, Y_train[k] = 5, np.array(Y_train[k], dtype=np.float).shape = (), Variable(b), np.array(), b = torch.from_numpy(np.array([Y_train[k]], dtype=np.float)).float()
]