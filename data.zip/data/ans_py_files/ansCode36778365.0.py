id = 36778365.0
[score = model:forward(input_case)
]