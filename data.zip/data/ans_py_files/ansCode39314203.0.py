id = 39314203.0
[l3 = nn.Linear(params.x3_size1, params.x3_size2)(x3)
]