id = 44982812.0
[DataLoader, DataLoader, nsamples = 10000
for i, image, label in enumerate(train_loader):
    if i  nsamples:
        break

    # Your training code here.
, itertools.islice, for image, label in itertools.islice(train_loader, stop=10000):

    # your training code here.
]