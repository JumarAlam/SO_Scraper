id = 28147346.0
[image.lena(), size(dim), require 'image'

local img = image.lena()
print(torch.typename(img)) -- torch.DoubleTensor

local nchan, height, width = img:size(1), img:size(2), img:size(3)
print('nb. channels: ' .. nchan) -- 3
print('width: ' .. width .. ', height: ' .. height) -- 512, 512
]