id = 43440045.0
[train = torch.range(1,10)
p = torch.randperm(10):long()
print(train:index(p))
]