id = 46386319.0
[torch.view, torch.squeeze]