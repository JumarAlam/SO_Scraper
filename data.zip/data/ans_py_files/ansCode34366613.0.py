id = 34366613.0
[subfolders = {}
counter = 0

local dirs = paths.dir(root-directory)
table.sort(dirs)

for i = 1, 447 do
    counter = counter + 1
    subfolders[counter] = dirs[i]
end
]