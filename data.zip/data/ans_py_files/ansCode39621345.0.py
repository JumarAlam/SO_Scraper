id = 39621345.0
[                   gradParameters:div(inputs:size(1))
                   f = f/inputs:size(1)
]