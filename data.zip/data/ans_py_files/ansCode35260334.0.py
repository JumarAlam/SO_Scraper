id = 35260334.0
[bb:resize(2,1)
, th bb:t()
 1  2
, bb:resize(bb:size(1),1)
]