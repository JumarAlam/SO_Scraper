id = 37520748.0
[for i = 1,niter do
  -- k-means computations...

  -- total counts
  totalcounts:add(counts)
end
, counts:sum(), niter, local maxiter = 40

local centroids, counts = unsup.kmeans(
  points,
  total_classes,
  maxiter,
  total_classes,
  function(i, _, totalcounts) if i &lt; maxiter then totalcounts:zero() end end,
  true
)
, local assignments = kmeans:quantize(points)

local counts = torch.zeros(total_classes):int()

for i=1,total_classes do
  counts[i] = assignments:eq(i):sum()
end
]