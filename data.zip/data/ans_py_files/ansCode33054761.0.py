id = 33054761.0
[function runfile(&lt;scriptName, ...)
opt = nil
arg = {...}
dofile(&lt;scriptName)
end
, runfile(&lt;scriptName,...)
]