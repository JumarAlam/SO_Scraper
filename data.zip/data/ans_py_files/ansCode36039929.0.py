id = 36039929.0
[The weights and biases in the network model will be reset based on the method provided.
, weight-init, math.sqrt(2/(fan_in + fan_out), torch.load(), torch.save(), weight-init() - train - torch.save() - torch.load()
]