id = 41858155.0
[./clean.sh, ~/torch, ./update.sh]