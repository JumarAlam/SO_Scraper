id = 37455770.0
[nn.SplitTable, ParallelCriterion, M = 100
C = 4
H = 64
W = 64
dataIn = torch.rand(M, C, H, W)

layerOfTables = nn.Sequential()
-- Because SplitTable discards the dimension it is applied on, we insert
-- an additional dimension.
layerOfTables:add(nn.Reshape(M,C,1,H,W))
-- We want to split over the second dimension (i.e. channels).
layerOfTables:add(nn.SplitTable(2, 5))

-- We use ConcatTable in order to create paths accessing to the data for 
-- numereous number of criterions. Each branch from the ConcatTable will 
-- have access to the data (i.e. the output table).
criterionPath = nn.ConcatTable()
-- Starting from offset 1, NarrowTable will select 2 elements. Since you 
-- want to use this portion as a 2 dimensional channel, we need to combine
-- then by using JoinTable. Without JoinTable, the output will be again a 
-- table with 2 elements. 
criterionPath:add(nn.Sequential():add(nn.NarrowTable(1, 2)):add(nn.JoinTable(2)))
-- SelectTable is simplified version of NarrowTable, and it fetches the desired element.
criterionPath:add(nn.SelectTable(3))
criterionPath:add(nn.SelectTable(4))

layerOfTables:add(criterionPath)

-- Here goes the criterion container. You can use this as if it is a regular
-- criterion function (Please see the examples on documentation page).
criterionContainer = nn.ParallelCriterion()
criterionContainer:add(nn.BCECriterion())
criterionContainer:add(nn.MSECriterion())
criterionContainer:add(nn.MSECriterion())
, dataOut = layerOfTables:forward(dataIn)
print(dataOut)
{
  1 : DoubleTensor - size: 100x2x64x64
  2 : DoubleTensor - size: 100x1x64x64
  3 : DoubleTensor - size: 100x1x64x64
}
]