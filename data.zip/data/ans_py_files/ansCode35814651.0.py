id = 35814651.0
[subprocess.check_output(['th', 'sample.lua', 'cv/lm_lstm_epoch3.54_0.9324.t7', '-gpuid', '-1', '-primetext', '"אמר הגאון הגרפקא המן איש טוב היה שנאמר"', '-temperature', '1.0', '-length', '1000'])
]