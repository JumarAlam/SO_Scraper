id = 39237567.0
[require(), "./?.so;./?.dll;/usr/local/?/init.so", ./foo.so, ./foo.dll, /usr/local/foo/init.so, require(), package.cpath, require(), - ROOT
    |-lua
    |-bin
, lua, script.lua, bin, mylib.so, mylib.so, script.lua, package.cpath = '/ROOT/bin/?.so;' .. package.cpath
libfuncs = require('mylib')
, ./?.so]