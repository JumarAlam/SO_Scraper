id = 39859068.0
[LEARN_RATE = 0.001, 1e-1, 1e-8, hiddenUnitVect = {2000, 4000, 6000, 8000, 10000}]