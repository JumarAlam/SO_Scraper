id = 45266055.0
[o:f(x, y)
, o.f(self, x, y)
, init, self, init, local X_train, y_train, sid_train = trainLoader:init(
    X_data[{{1, a}, {}, {}}],
    y_data[{{1, a}, {}}],
    sid_data[{{1, a}, {}}],
    10, true)
, BatchLoader, function BatchLoader.new()
    local self = setmetatable({}, BatchLoader)
    self.epoch_done = false
    return self
end
, function BatchLoader.new()
    return setmetatable({epoch_done = false}, BatchLoader)
end
, local trainLoader = BatchLoader.new()
]