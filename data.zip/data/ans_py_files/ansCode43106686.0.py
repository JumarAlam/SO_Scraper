id = 43106686.0
[conda install pytorch=0.1.10 torchvision -c soumith]