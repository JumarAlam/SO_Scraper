id = 36677200.0
[\init.lua
\main.lua
\test-0.1-1.rockspec
\Extensions\a.lua
\Extensions\b.lua
, luarocks install/make, ., .lua, package = "torch-test"
 version = "0.1-1"
 source = {
    url = "..."
 }
 description = {
    summary = "A test class",
    detailed = [[
       Just an example
    ]],
    license = "MIT/X11",
    maintainer = "Jon Doe"
 }
 dependencies = {
    "lua ~ 5.1",
    "torch = 7.0",
 }
 build = {
  type = 'builtin',
  modules = {
      ["test.init"] = 'init.lua',
      ["test.main"] = 'main.lua',
      ["test.Extensions.a"] = 'a.lua',
      ["test.Extensions.b"] = 'b.lua'
    }
  }
, init.lua, test = torch.class('test')
function test:__init()
  self.data = {}
end
return test
, loadfile(), init.lua, a.lua, local params = {...}
local test = params[1]
function test:a()
  print("a")
end
, b.lua, local params = {...}
local test = params[1]
function test:b()
  print("b")
end
, init.lua, init.lua, require 'lfs'

local file_exists = function(name)
   local f=io.open(name,"r")
   if f~=nil then io.close(f) return true else return false end
end

-- If we're in development mode the default path should be the current
local test_path = "./?.lua"
local search_4_file = "Extensions/load_batch"
if (not file_exists(string.gsub(test_path, "?", search_4_file))) then
  -- split all paths according to ;
  for path in string.gmatch(package.path, "[^;]+;") do
    -- remove trailing ;
    path = string.sub(path, 1, string.len(path) - 1)
    if (file_exists(string.gsub(path, "?", "test/" .. search_4_file))) then
      test_path = string.gsub(path, "?", "test/?")
      break;
    end
  end
  if (test_path == nil) then
    error("Can't find package files in search path: " .. tostring(package.path))
  end
end

local main_file = string.gsub(test_path,"?", "main")
local test = assert(loadfile(main_file))()

-- Load all extensions, i.e. .lua files in Extensions directory
ext_path = string.gsub(test_path, "[^/]+$", "") .. "Extensions/"
for extension_file,_ in lfs.dir (ext_path) do
  if (string.match(extension_file, "[.]lua$")) then
    local file = ext_path .. extension_file
    assert(loadfile(file))(test)
  end
end

return test
]