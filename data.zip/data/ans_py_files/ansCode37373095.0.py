id = 37373095.0
[require 'torch';
require 'nn';
require 'nnx';
]