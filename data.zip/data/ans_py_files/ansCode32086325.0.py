id = 32086325.0
[model.modules[2].weight
]