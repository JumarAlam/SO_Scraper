id = 38596784.0
[seqlen x batchsize, 0 0
1 2
1 2
2 3
0 0
2 3
2 3
1 2
, rnn]