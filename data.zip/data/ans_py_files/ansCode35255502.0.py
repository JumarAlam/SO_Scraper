id = 35255502.0
[th torch.cmul(q,w)
  1   4   9
  4  16  36
, q:cmul(w), z=torch.cmul(q,w)]