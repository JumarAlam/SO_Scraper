id = 44976388.0
[EMDCriterion, torch.histc, for i=1,#images do 
    print(images[i])
    local hist = torch.histc(images[i][1]:view(images[i][1]:nElement()),20,-100,100)
    r[i] = hist:reshape(1,hist:nElement())
end
, criterion:forward(r[i],r[j])
print(criterion.loss)
, nil, local loss = criterion:forward(r[i],r[j])
sumdistance = sumdistance + loss
, criterion = nn.EMDCriterion(), for]