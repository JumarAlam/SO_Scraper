id = 44571825.0
[del_W, del_H = grad_cost(W, H)
, grad=f_grad(w,sd,*args)
, gt_w+= np.square(del_W)
gt_h+= np.square(del_H)
, gti+=grad**2
, mod_learning_rate_W = np.divide(learning_rate, np.sqrt(gt_w+eps))
mod_learning_rate_H = np.divide(learning_rate, np.sqrt(gt_h+eps))
, adjusted_grad = grad / (fudge_factor + np.sqrt(gti))
, W =  W-del_W*mod_learning_rate_W
H =  H-del_H*mod_learning_rate_H
, w = w - stepsize*adjusted_grad
, adagrad.py]