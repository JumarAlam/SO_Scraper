id = 38083259.0
[X_py = {X_py_1, X_py_2, X_py_3, X_py_4, X_py_5, X_py_6}
for i, v in ipairs(X_py) do
    v = fromfile(('%s/x_py_%.2f.bin'):format(data_dir, scales[i-1]))
end
]