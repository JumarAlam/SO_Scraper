id = 44353013.0
[model_2.layer[0].weight
]