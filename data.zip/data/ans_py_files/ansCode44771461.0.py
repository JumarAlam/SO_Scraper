id = 44771461.0
[net:add(nn.JoinTable(1,8)), net:add(nn.JoinTable(1,3)), require 'nn'
require 'cutorch'
require 'cunn'
require 'cudnn'

net = nn.Sequential()
c = nn.ParallelTable()
c:add(nn.SpatialConvolution(3,48,11,11,4,4,2,2)) 
c:add(nn.SpatialConvolution(3,48,11,11,4,4,2,2))
net:add(c)
net:add(nn.JoinTable(1,3))
net:add(nn.SpatialBatchNormalization(96))
net:add(nn.ReLU(true))
net:add(nn.SpatialMaxPooling(3,3,2,2)) 

net:cuda()

input1 = torch.rand(128,3,227, 227):cuda()
input2 = torch.rand(128,3,227,227):cuda()

out = net:forward({input1, input2})

print(out:size())
]