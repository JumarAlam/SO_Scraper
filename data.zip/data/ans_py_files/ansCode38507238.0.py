id = 38507238.0
[permute(x, y, z), itorch.image(your_image), x, y, z, x = torch.Tensor(3,4,2,5)
 x:size()
 3
 4
 2
 5
[torch.LongStorage of size 4]

y = x:permute(2,3,1,4) -- equivalent to y = x:transpose(1,3):transpose(1,2)
 y:size()
 4
 2
 3
 5
[torch.LongStorage of size 4]
, th t = torch.Tensor(5,5,3)


[0.0001s]   
th t = t:permute(3,1,2)
                                                                          [0.0001s] 
th t:size()
 3
 5
 5
[torch.LongStorage of size 3]
                                                                      [0.0001s] 
th t[{2}]:fill(2)
 2  2  2  2  2
 2  2  2  2  2
 2  2  2  2  2
 2  2  2  2  2
 2  2  2  2  2
[torch.DoubleTensor of size 5x5]

                                                                      [0.0003s] 
th t[{3}]:fill(3)
 3  3  3  3  3
 3  3  3  3  3
 3  3  3  3  3
 3  3  3  3  3
 3  3  3  3  3
[torch.DoubleTensor of size 5x5]

                                                                      [0.0004s] 
th w = t:reshape(1,t:size(2)*t:size(3)*3)
                                                                      [0.0001s] 
th w
Columns 1 to 26
 0  0  0  0  0  0  0  0  0  0  0  0  0  0  0  0  0  0  0  0  0  0  0  0  0  2

Columns 27 to 52
 2  2  2  2  2  2  2  2  2  2  2  2  2  2  2  2  2  2  2  2  2  2  2  2  3  3

Columns 53 to 75
 3  3  3  3  3  3  3  3  3  3  3  3  3  3  3  3  3  3  3  3  3  3  3
[torch.DoubleTensor of size 1x75]

th x = w:reshape(3,5,5)
                                                                      [0.0001s] 
th x
(1,.,.) = 
  0  0  0  0  0
  0  0  0  0  0
  0  0  0  0  0
  0  0  0  0  0
  0  0  0  0  0

(2,.,.) = 
  2  2  2  2  2
  2  2  2  2  2
  2  2  2  2  2
  2  2  2  2  2
  2  2  2  2  2

(3,.,.) = 
  3  3  3  3  3
  3  3  3  3  3
  3  3  3  3  3
  3  3  3  3  3
  3  3  3  3  3
[torch.DoubleTensor of size 3x5x5]
]