id = 43454611.0
[X = torch.rand(10000, 3, 50, 50)
inds = torch.randperm(X:size(1)):long()
train_inds = inds:narrow(1, 1, nTrain)
valid_inds = inds:narrow(1, nTrain + 1, X:size(1) - nTrain)
X_train = X:index(1, train_inds)
X_valid = X:index(1, valid_inds)
]