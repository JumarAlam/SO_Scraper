id = 45848698.0
[transform.Compose, .ToTensor(), .Scale(), Pytorch, transform = transforms.Compose(
                   [transforms.Scale((32,32)),
                    transforms.ToTensor(),
                    transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])
, PIL Image]