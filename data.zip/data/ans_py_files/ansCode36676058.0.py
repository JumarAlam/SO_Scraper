id = 36676058.0
[m:forward({y, x:view(4,1,5):expandAs(y)})
]