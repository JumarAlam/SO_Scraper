id = 45113863.0
[brew install hdf5@1.8
, hdf5._config = {
  HDF5_INCLUDE_PATH = "/usr/local/Cellar/hdf5@1.8/1.8.18/include",
  HDF5_LIBRARIES = "/usr/local/Cellar/hdf5@1.8/1.8.18/lib/libhdf5.dylib;/usr/local/opt/szip/lib/libsz.dylib;/usr/lib/libz.dylib;/usr/lib/libdl.dylib;/usr/lib/libm.dylib"
}
, local process = io.popen("gcc -D '_Nullable=' -E " .. headerPath) -- TODO pass -I
]