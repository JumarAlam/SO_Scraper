id = 40497573.0
[$ luarocks install graphicsmagick, require 'image'
gm = require 'graphicsmagick'

-- change the string
local jpg_filename = string.gsub(train_files[i],".[Bb][Mm][Pp]$",".jpg")
-- get the info so we can build the size string
local image_info = gm.info(train_path .. train_files[i])
-- convert takes a size string h x w
local size_string = image_info["height"] .. "x" .. image_info["width"]

gm.convert{
  input = train_path .. train_files[i],
  output = train_path .. jpg_filename,
  size = size_string,
  quality = 95,
  verbose = true
}
local img_raw = image.load(train_path .. jpg_filename):mul(255)
]