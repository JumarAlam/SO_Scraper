id = 35764922.0
[lc, lt, set terminal x11 0 position 1200,20 persist
set multiplot layout 2,1
plot '-' lc rgb 'blue', '-' lc rgb 'red'
0 0
100 30
e
0 30
100 60
e
plot '-' lc rgb 'green'
0 60
100 90
e
unset multiplot
, with lines, plot '-' lc rgb 'blue' with lines, '-' lc rgb 'red' with lines
plot '-' lc rgb 'green' with lines
, set style data lines]