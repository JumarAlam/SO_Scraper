id = 38316377.0
[local z= torch.cinv(x) -- to make a copy
x:cinv() -- for an in place element wise inverse
]