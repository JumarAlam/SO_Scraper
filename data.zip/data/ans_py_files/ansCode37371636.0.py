id = 37371636.0
[optim, optim.sgd, nil, optim]