id = 43812338.0
[targetnp=targets.numpy()
idxs=np.where(targetnp0)[1]
new_targets=torch.LongTensor(idxs)
loss=criterion(output,new_targets)
]