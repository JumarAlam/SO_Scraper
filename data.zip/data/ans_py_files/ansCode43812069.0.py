id = 43812069.0
[y_train = np.array([[152.],[185.],[180.],[196.],[142.]],dtype=np.float32)
]