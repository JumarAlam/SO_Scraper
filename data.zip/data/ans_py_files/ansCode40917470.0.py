id = 40917470.0
[gnuplot
set title "Mean accuracy"
set xlabel "Epochs"
set ylabel "Accuracy (%)"
set yrange [0:100]
plot 'test.log' title "Testing" with linespoints ls 1 linetype 6,'train.log' title "Training" with linespoints ls 1 linetype 7  
]