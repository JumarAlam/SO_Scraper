id = 42797818.0
[tensor_a = torch.Tensor(n, 2A, B,C)
-- Initialize tensor_a with the data

tensor_b = torch.Tensor(n, A, B, C)
tensor_b = tensor_a[{{},1,{},{}}]
tensor_c = torch.Tensor(n, A, B, C)
tensor_c = tensor_a[{{},2,{},{}}]
]