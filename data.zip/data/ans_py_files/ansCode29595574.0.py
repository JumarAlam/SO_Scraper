id = 29595574.0
[which ipython, echo $PATH, .bashrc, cd, .bashrc, .profile]