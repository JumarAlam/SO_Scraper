id = 34764488.0
[function split(str)
    tbl = {}
    for c in str:gmatch('.') do
         table.insert(tbl, c)
    end
    return tbl
end

a = '01234'
b = '12345'

tens = torch.Tensor{split(a), split(b)} 
]