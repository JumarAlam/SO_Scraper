id = 37304606.0
[require 'torch'

-- define some dummy A class
local A = torch.class('A')
function A:__init(stuff)
  self.stuff = stuff
  print('inside __init of A')
end

function A:__call__(arg1)
print('inside __call__ of A')
end

-- define some dummy B class, inheriting from A
local B,parent = torch.class('B', 'A')

function B:__init(stuff)
  self.stuff = stuff
  print('inside __init of B')
end

function B:__call__(arg1)
print('inside __call__ of B')
end
a=A()()
b=B()()
, inside __init of A
inside __call__ of A
inside __init of B
inside __call__ of B
,     require 'torch'

    -- define some dummy A class
    local A = torch.class('A')
    function A:__init(stuff)
      self.stuff = stuff
      print('inside __init of A')
    end

    function A:__call__(arg1)
    print('inside __call__ of A')
    end

    -- define some dummy B class, inheriting from A
    local B,parent = torch.class('B', 'A')

    b=B()()
,     inside __init of A
    inside __call__ of A
]