id = 34762233.0
[torch.topk,  t = torch.Tensor{9, 1, 8, 2, 7, 3, 6, 4, 5}

-- obtain the 3 smallest elements
 res = t:topk(3)
 print(res)
 1
 2
 3
[torch.DoubleTensor of size 3]

-- you can also get the indices in addition
 res, ind = t:topk(3)
 print(ind)
 2
 4
 6
[torch.LongTensor of size 3]

-- alternatively you can obtain the k largest elements as follow
-- (see the API documentation for more details)
 res = t:topk(3, true)
 print(res)
 9
 8
 7
[torch.DoubleTensor of size 3]
]