id = 40036562.0
[function train()
  do
    local in = loadInput()
    local in_1 = someImageProcessing(in)
    local in_2 = someImageProcessing(in)
    network:forward( ...some manipulation on in_1,in_2...)
    network:backward()
  end
    collectgarbage('collect')
    collectgarbage('collect')
    print debug.getlocal -- all local variables.
, in]