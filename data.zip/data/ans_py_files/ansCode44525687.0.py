id = 44525687.0
[torch.mm, torch.mm(a, b)
, torch.dot(), np.dot(), torch.dot(), a, b, a, b, torch.mm(), np.dot(), torch.matmul, 2D, 1D, np.dot, matrix x matrix, matrix x vector, vector x vector, # 1D inputs, same as torch.dot
a = torch.rand(n)
b = torch.rand(n)
torch.matmul(a, b) # torch.Size([])

# 2D inputs, same as torch.mm
a = torch.rand(m, k)
b = torch.rand(k, j)
torch.matmul(a, b) # torch.Size([m, j])
]