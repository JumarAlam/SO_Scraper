id = 37606794.0
[pairs, ipairs, pairs (t)
, t, __pairs, t, next, t, nil, for k,v in pairs(t) do body end
, t, next, next (table [, index])
, nil, next, nil, next, next(t), next]