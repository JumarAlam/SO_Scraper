id = 44609160.0
[torch.svd(), TypeError, import torch
from torch.autograd import Function
from torch.autograd import Variable

A = Variable(torch.randn(10,10), requires_grad=True)
u, s, v = torch.svd(A) # raises TypeError
, backward(), NotImplementedError, class my_function(Function): # forgot to define backward()

    def forward(self, x):
        return 2 * x

A = Variable(torch.randn(10,10))
B = my_function()(A)
C = torch.sum(B)
C.backward() # will raise NotImplementedError
, backward(), torch.abs(), backward(), A = Variable(torch.Tensor([-1,0,1]),requires_grad=True)
B = torch.abs(A)
B.backward(torch.Tensor([1,1,1]))
A.grad.data
, backward(), requires_grad, Variables, nn.Module(), loss, requires_grad, requires_grad, _Loss, nn.Module, _Loss, AssertionError, volatile, requires_grad = False, nn.Sequential(), nn.Module]