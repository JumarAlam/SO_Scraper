id = 39926247.0
[local loss_x = criterion:forward(model:forward(inputs), target)
, local loss_x = criterion:forward(model:forward(inputs:cuda()), target)
, inputs = inputs:cuda()]