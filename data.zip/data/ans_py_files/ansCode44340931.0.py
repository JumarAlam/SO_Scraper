id = 44340931.0
[Tensor, autograd.Variable, a.data, a.data.numpy(), numpy, a = a.data  # a is now torch.Tensor
a = a.numpy()  # a is now numpy array
]