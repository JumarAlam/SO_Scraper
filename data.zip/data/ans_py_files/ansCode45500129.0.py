id = 45500129.0
[git clone https://github.com/deepmind/torch-totem.git
cd torch-totem
cp rocks/totem-0-0.rockspec ./   #copy the rockspec file in the root dirctory of project
luarock make
, Updating manifest for xxx/torch/install/lib/luarocks/rocks
totem 0-0 is now built and installed in xxx/torch/install/ (license: BSD)
]