id = 45086706.0
[Variable, input = Variable(letterToTensor('A'))
hidden = Variable(torch.zeros(1, n_hidden))
output, next_hidden = rnn(input, hidden)
, [name_length, a_found, e_found, ...]]