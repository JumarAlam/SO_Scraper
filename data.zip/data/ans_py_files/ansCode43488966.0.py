id = 43488966.0
[H_out, W_out, dilation=n, 1x1, nxn, dilation=1]