id = 34577511.0
[t = torch.Tensor({{0, -1, -3}, {6, 5, 0}, {0.3, 0.6, 0.9}})
minpos = torch.min(t[t:gt(0)])

0.3
, mask = t:eq(minpos)

 0  0  0
 0  0  0
 1  0  0
[torch.ByteTensor of size 3x3]
, function indexesOf(mask)
    local lin_indices = torch.linspace(1, mask:nElement(), mask:nElement())[mask]
    if lin_indices:nElement() == 0 then return nil end

    local sp_indices = torch.LongTensor(mask:nDimension(), lin_indices:nElement())
    sp_indices[1] = lin_indices - 1
    local divisor = mask:nElement()
    for d = 1, mask:nDimension() - 1 do
        divisor = divisor / mask:size(d)
        local fdiv = torch.div(sp_indices[d], divisor)
        sp_indices[d + 1] = sp_indices[d] - fdiv * divisor
        sp_indices[d] = fdiv
    end
    return sp_indices:t() + 1
end

indexes = indexesOf(mask)

 3  1
[torch.LongTensor of size 1x2]
]