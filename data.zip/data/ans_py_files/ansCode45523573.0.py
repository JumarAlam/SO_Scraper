id = 45523573.0
[running_std, running_var, ptb:add(some_model:clone('weight','bias', 'gradWeight','gradBias','running_mean','running_var'))
]