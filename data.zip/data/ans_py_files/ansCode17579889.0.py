id = 17579889.0
[typename, template, template&lt;typename T
struct A {
  typedef int result_type;

  void f() {
    // error, "this" is dependent, "template" keyword needed
    this-g&lt;float();

    // OK
    g&lt;float();

    // error, "A&lt;T" is dependent, "typename" keyword needed
    A&lt;T::result_type n1;

    // OK
    result_type n2; 
  }

  template&lt;typename U
  void g();
};
, A::result_type, int, this-g, g, A, A, A, A&lt;T, ::A&lt;T, A::NestedClass, A, CurrentInstantiation::Foo, Foo, CurrentInstantiationTyped-Foo, A *a = this; a-Foo, typename, template, A&lt;T, T, A&lt;T::result_type, struct B {
  typedef int result_type;
};

template&lt;typename T
struct C { }; // could be specialized!

template&lt;typename T
struct D : B, C&lt;T {
  void f() {
    // OK, member of current instantiation!
    // A::result_type is not dependent: int
    D::result_type r1;

    // error, not a member of the current instantiation
    D::questionable_type r2;

    // OK for now - relying on C&lt;T to provide it
    // But not a member of the current instantiation
    typename D::questionable_type r3;        
  }
};
, D::result_type, D::f, C, template&lt;
struct C&lt;int {
  typedef bool result_type;
  typedef int questionable_type;
};
, D&lt;int::f, typename, template, D, typename D::questionable_type, DependentTypeName::Foo, DependentTypedName-Foo, Foo, h, A, void h() {
  typename A&lt;T::questionable_type x;
}
, A&lt;T::h, T, A, A, questionable_type, A&lt;T::questionable_type, struct B { void f(); };
struct A : virtual B { void f(); };

template&lt;typename T
struct C : virtual B, T {
  void g() { this-f(); }
};

int main() { 
  C&lt;A c; c.g(); 
}
, this-f, A::f, B::f, C&lt;A::g, A::f]