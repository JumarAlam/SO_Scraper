id = 42131717.0
[nn.ClassNLLCriterion, for k,v in pairs(criterion) do
    print(k,v)
end
, -- Copy/Paste from trepl/init.lua
local function sizestr(x)
  local strt = {}
  if _G.torch.typename(x):find('torch.*Storage') then
    return _G.torch.typename(x):match('torch%.(.+)') .. ' - size: ' .. x:size()
  end
  if x:nDimension() == 0 then
    table.insert(strt, _G.torch.typename(x):match('torch%.(.+)') .. ' - empty')
  else
    table.insert(strt, _G.torch.typename(x):match('torch%.(.+)') .. ' - size: ')
    for i=1,x:nDimension() do
      table.insert(strt, x:size(i))
      if i ~= x:nDimension() then
        table.insert(strt, 'x')
      end
    end
  end
  return table.concat(strt)
end


local function sutoringu(elem)
  local str = ''
  if torch.isTensor(elem) then
    str = sizestr(elem)
  else
    str = tostring(elem)
  end
  return str
end

local str = '{\n'
local tab = '  '
for k,v in pairs(criterion) do
  str = str .. tab .. k .. ' : ' .. sutoringu(v) .. '\n'
end
str = str .. '}'

print(str)
]