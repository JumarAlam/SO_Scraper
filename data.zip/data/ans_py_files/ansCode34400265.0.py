id = 34400265.0
[sudo, sudo source ~/.bashrc, source, sudo, .bashrc, sudo, luarocks, luarocks search, luarocks]