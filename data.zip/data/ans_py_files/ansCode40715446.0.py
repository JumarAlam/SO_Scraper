id = 40715446.0
[image.save('train100.jpg', trainData[100])
]