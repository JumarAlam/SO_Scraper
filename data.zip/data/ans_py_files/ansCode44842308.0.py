id = 44842308.0
[ img_nhwc = torch.randn(10, 480, 640, 3)
 img_nhwc.size()
torch.Size([10, 480, 640, 3])
 img_nchw = img_nhwc.permute(0, 3, 1, 2)
 img_nchw.size()
torch.Size([10, 3, 480, 640])
]