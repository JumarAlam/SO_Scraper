id = 31033424.0
[mean = data:mean(1)
data:add(-1, mean:expandAs(data))
]