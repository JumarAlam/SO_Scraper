id = 46336444.0
[unet = UnetGenerator(512,512,4)
layers = list(unet.children())
len(layers)
, l = layers[0]
conv = list(l.children())[0][0]
conv.kernel_size = (2,2)
]