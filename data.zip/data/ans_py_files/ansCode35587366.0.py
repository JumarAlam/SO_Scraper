id = 35587366.0
[luarocks-5.1 path, $ luarocks-5.1 path
export LUA_PATH='/home/markus/.luarocks/share/lua/5.1/?.lua;/home/markus/.luarocks/share/lua/5.1/?/init.lua;/usr/share/lua/5.1/?.lua;/usr/share/lua/5.1/?/init.lua;./?.lua;/usr/lib/lua/5.1/?.lua;/usr/lib/lua/5.1/?/init.lua'
export LUA_CPATH='/home/markus/.luarocks/lib/lua/5.1/?.so;/usr/lib/lua/5.1/?.so;./?.so;/usr/lib/lua/5.1/loadall.so'
, ~/.bashrc, $ luarocks-5.1 path  ~/.bashrc
, ~/.bashrc, source ~/.bashrc]