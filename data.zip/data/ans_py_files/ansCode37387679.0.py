id = 37387679.0
[local Bar, parent = torch.class('torch.Bar', 'Foo')
, function Bar:__init(stuff)
    parent.__init(self)

    self.stuff = stuff
end
]