id = 28814333.0
[mlp2 = mlp:toModule(datasource:trainSet():sub(1,2))
input = testImageTensor:view(1, 1, 32, 32)
output = mlp2:forward(input)
, inputView = dp.ImageView('bchw', testImageTensor:view(1, 1, 32, 32))
outputView = mlp:forward(inputView, dp.Carry{nSample=1})
output = outputView:forward('b')
]