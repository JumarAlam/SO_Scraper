id = 35956629.0
[sub = ls:index(1, torch.LongTensor{2, 7, 9})
, [Tensor] index(dim, index)]