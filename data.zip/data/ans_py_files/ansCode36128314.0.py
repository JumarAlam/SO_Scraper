id = 36128314.0
[install-deps, easy_install, pip, install.sh]