id = 37405076.0
[ffi, luarocks install torchffi]