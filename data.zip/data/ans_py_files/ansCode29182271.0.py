id = 29182271.0
[local, data, points, unsup.kmeans, -- batch size = 5000, no callback, verbose mode
centroids, counts = unsup.kmeans(points, 10, 15, 5000, nil, true)
]