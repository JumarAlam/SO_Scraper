id = 39232187.0
[:type(), cutorch = require('cutorch')

x = torch.Tensor(3,3)
x = x:cuda()

if x:type() == 'torch.CudaTensor' then
    print('x is CUDA tensor')
else
    print('x is normal tensor')
end
]