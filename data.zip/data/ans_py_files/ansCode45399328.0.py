id = 45399328.0
[scores,  scores=torch.floor(torch.rand(4,10)*100)
 =scores
 9   1  90  12  62   1  62  86  46  27
 7   4   7   4  71  99  33  48  98  63
 82   5  73  84  61  92  81  99  65   9
 33  93  64  77  36  68  89  44  19  25
[torch.DoubleTensor of size 4x10]
, N,  values,indexes=scores:sort(2)
,  =values
  1   1   9  12  27  46  62  62  86  90
  4   4   7   7  33  48  63  71  98  99
  5   9  61  65  73  81  82  84  92  99
  19  25  33  36  44  64  68  77  89  93
  [torch.DoubleTensor of size 4x10]

 =indexes
  2   6   1   4  10   9   5   7   8   3
  2   4   1   3   7   8  10   5   9   6
  2  10   5   9   3   7   1   4   6   8
  9  10   1   5   8   3   6   4   7   2
  [torch.LongTensor of size 4x10]
, i-th, values, i-th, scores, indexes, N,  N_best_indexes=indexes[{{},{indexes:size(2)-N+1,indexes:size(2)}}]
 N_best_values=values[{{},{values:size(2)-N+1,values:size(2)}}]
, N=3,  return N_best_indexes
 7  8  3
 5  9  6
 4  6  8
 4  7  2
[torch.LongTensor of size 4x3]

 return N_best_values
 62  86  90
 71  98  99
 84  92  99
 77  89  93
[torch.DoubleTensor of size 4x3]
, k-th, j, N_best_values[{{j},{values:size(2)-k+1}]], scores, row, column, row=j
column=N_best_indexes[{{j},indexes:size(2)-k+1}}]. 
, k=1, 99, 2nd, 6th, scores, values[{{2},values:size(2)}}], 99, indexes[{{2},{indexes:size(2)}}], 6, scores]