id = 45778299.0
[concat, require"torch"
nn=require"nn"
local NX,NY = 2,6 --sizes of inputs
local Y1, Y2 = 1, 4 --normalize only data between these constraints
local DIMENSION_INDEX=2--dimension on which you want to split your input (NY here)
local input=torch.randn(NX,NY)--example input

--network construction
local normalize_part = nn.Sequential()
normalize_part:add(nn.Narrow(DIMENSION_INDEX,Y1,Y2))
normalize_part:add(nn.Normalize(2))


local dont_change_part=nn.Sequential()
dont_change_part:add(nn.Narrow(DIMENSION_INDEX,Y2+1,NY-Y2))


local partial_normalization=nn.Concat(DIMENSION_INDEX)
partial_normalization:add(normalize_part)
partial_normalization:add(dont_change_part)

--partial_normalization is ready for use:
print(input)
print( partial_normalization:forward(input))

--can be used as a block in a greater network
local main_net=nn.sequential()
main_net:add(partial_normalization)
, nn.normalize, (X - mean(x)) / std(x)]