id = 40174308.0
[model:add(nn.LogSoftMax()), log, model = nn.Sequential()
model:add(nn.Linear(3, 7));
model:add(nn.LogSoftMax());
criterion = nn.ClassNLLCriterion();
data = torch.Tensor{1914,  1993 , 2386}
print (model:forward(data):exp())

  0.0000
  0.0000
  1.0000
  0.0000
  0.0000
  0.0000
  0.0000 [torch.DoubleTensor of size 7]
]