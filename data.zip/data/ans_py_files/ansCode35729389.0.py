id = 35729389.0
[jupyter kernelspec list, /usr/local/share/jupyter/kernels/]