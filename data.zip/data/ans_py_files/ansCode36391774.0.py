id = 36391774.0
[==, a = torch.Tensor(3, 5):fill(1)
b = torch.Tensor(3, 5):fill(1)
print(a == b)
 false
print(a:eq(b):all())
 true
]