id = 38685757.0
[input = nn.Identity()()
L1 = nn.ReLU(true)(nn.Linear(100, 20)(input))
L2 = nn.ReLU(true)(nn.Linear(20, 10)(L1))
L3 = nn.Linear(10, 2)(L2)

gmod = nn.gModule({input}, {L3, L2})
]